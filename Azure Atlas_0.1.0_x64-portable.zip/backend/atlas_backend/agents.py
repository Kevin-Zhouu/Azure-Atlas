"""Turns a registered agent into something the desktop shell can actually start.

Atlas keeps the decision about *what* to run here, in Python, next to the configuration it
reads, and leaves the desktop shell with the much smaller job of owning a pseudo-terminal.
Nothing in this module starts a process.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from .launcher_config import Agent, ConfigError, LauncherConfig, agents_dir, sync_agent_files

#: Names Copilot CLI looks for on PATH. On Windows the shim is usually a .cmd or .exe.
_EXECUTABLES = ("copilot",)
_INSTALL_HINT = (
    "GitHub Copilot CLI is not installed. Install it with "
    "`winget install GitHub.Copilot`, then sign in with `copilot login`. "
    "Everything else in Azure Atlas works without it."
)


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid")


class AgentLaunch(Model):
    """A fully resolved command line, ready for the shell to spawn in a terminal."""

    agent: str
    title: str
    subtitle: str
    program: str
    arguments: list[str] = Field(default_factory=list)
    cwd: str | None = None
    #: Rendered for the engineer above the terminal, so nothing runs that they cannot read.
    display: str


class AgentStatus(Model):
    available: bool
    path: str | None
    directory: str
    message: str


def copilot_path() -> str | None:
    """Where Copilot CLI lives on this machine, or ``None`` when it is not installed."""
    for name in _EXECUTABLES:
        found = shutil.which(name)
        if found:
            return found
    return None


def status() -> AgentStatus:
    found = copilot_path()
    return AgentStatus(
        available=found is not None,
        path=found,
        directory=str(agents_dir()),
        message="" if found else _INSTALL_HINT,
    )


def find_agent(config: LauncherConfig, name: str) -> Agent | None:
    wanted = name.strip().removeprefix("/").casefold()
    for agent in config.preferences.agents:
        if agent.name.casefold() == wanted:
            return agent
    return None


def _working_directory(config: LauncherConfig, agent: Agent) -> str | None:
    if not agent.repo:
        return None
    for repo in config.repositories:
        if repo.alias.casefold() == agent.repo.casefold():
            return repo.path if Path(repo.path).is_dir() else None
    return None


def _quote(value: str) -> str:
    return value if value and not any(character.isspace() for character in value) else f'"{value}"'


def resolve(config: LauncherConfig, name: str, prompt: str = "") -> AgentLaunch:
    """Builds the command line for ``/agent <name> [prompt]``.

    ``copilot`` agents start an interactive Copilot CLI session using the custom agent file
    Atlas writes for them; ``command`` agents run the PowerShell line the engineer configured,
    with ``{arg}`` replaced by the rest of what they typed.
    """
    agent = find_agent(config, name)
    if agent is None:
        known = ", ".join(item.name for item in config.preferences.agents)
        raise ConfigError(
            (f"Unknown agent: {name}. " if name.strip() else "An agent name is required. ")
            + (f"Registered agents: {known}." if known else "Import one under Preferences \u2192 Agents.")
        )
    prompt = prompt.strip()
    cwd = _working_directory(config, agent)

    if agent.mode == "command":
        command = agent.command.replace("{arg}", prompt).replace("{prompt}", prompt).strip()
        return AgentLaunch(
            agent=agent.name,
            title=f"/agent {agent.name}",
            subtitle=agent.description or command,
            program="powershell.exe",
            arguments=["-NoLogo", "-NoExit", "-Command", command],
            cwd=cwd,
            display=command,
        )

    executable = copilot_path()
    if executable is None:
        raise ConfigError(_INSTALL_HINT)
    directory = str(sync_agent_files(config))
    arguments = ["--add-dir", directory, "--agent", agent.name, "--banner"]
    if agent.model:
        arguments += ["--model", agent.model]
    if prompt:
        arguments += ["-i", prompt]
    return AgentLaunch(
        agent=agent.name,
        title=f"/agent {agent.name}",
        subtitle=agent.description or f"Copilot CLI \u00b7 {agent.name}",
        program=executable,
        arguments=arguments,
        cwd=cwd,
        display=" ".join(["copilot", *(_quote(value) for value in arguments)]),
    )


def plain_terminal(config: LauncherConfig) -> AgentLaunch:
    """A Copilot CLI session with no agent behind it, for ``/agent`` with nothing to run."""
    executable = copilot_path()
    if executable is None:
        raise ConfigError(_INSTALL_HINT)
    _ = config
    return AgentLaunch(
        agent="",
        title="Copilot CLI",
        subtitle="A plain Copilot CLI session",
        program=executable,
        arguments=["--banner"],
        cwd=os.environ.get("USERPROFILE") or str(Path.home()),
        display="copilot",
    )
