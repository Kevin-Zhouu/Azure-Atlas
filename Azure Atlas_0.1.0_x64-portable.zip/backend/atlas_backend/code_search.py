"""Organization-wide Azure DevOps Code Search using the local Azure CLI identity."""

from __future__ import annotations

import asyncio
import os
from urllib.parse import quote, urlencode, urlsplit, unquote

import httpx

from . import azure_auth
from .launcher_config import LauncherConfig, ado_organization

RESOURCE = "499b84ac-1321-427f-aa17-267ca6975798"

# Where /code looks before an engineer has configured anything. Empty by default so no
# organization ships with the source; set ATLAS_DEFAULT_ADO_ORGANIZATION (and optionally
# ATLAS_DEFAULT_ADO_PROJECT) to give your team a working default.
DEFAULT_ORGANIZATION = os.environ.get("ATLAS_DEFAULT_ADO_ORGANIZATION", "")
DEFAULT_PROJECT = os.environ.get("ATLAS_DEFAULT_ADO_PROJECT", "")

NOTHING_CONFIGURED = (
    "No Azure DevOps organization is configured. Add one under Preferences → Code search."
)

# Codes describing a query Azure DevOps will never accept. Retrying or trying
# another organization cannot help, so these stay fatal.
FATAL_INFO_CODES = {
    3: "The search request is invalid.",
    4: "Prefix wildcards are not supported.",
    5: "Multiword queries with code filters are not supported.",
    19: "Phrase queries with code type filters are not supported.",
    20: "Wildcard queries with code type filters are not supported.",
}

# Codes describing a transient or partial condition. Azure DevOps still returns
# whatever it managed to find, so these only ever become a warning.
PARTIAL_INFO_CODES = {
    1: "the organization is being reindexed",
    2: "code indexing has not started",
    6: "the organization is being onboarded",
    7: "onboarding or reindexing is in progress",
    8: "Azure DevOps limited the result count",
    9: "branches are still being indexed",
}


class CodeSearchError(Exception):
    pass


def _describe(organization: str, info: int) -> str:
    known = PARTIAL_INFO_CODES.get(info)
    if known:
        return f"{organization}: {known}. Results may be incomplete."
    return f"{organization}: Azure DevOps reported status {info}, so results may be incomplete."


async def _search(organization: str, query: str, skip: int, top: int, token: str, project: str = "", repository: str = ""):
    payload = {"searchText": query, "$skip": skip, "$top": top, "includeFacets": False}
    if project:
        payload["filters"] = {"Project": [project]}
    if repository:
        payload.setdefault("filters", {})["Repository"] = [repository]
    try:
        async with httpx.AsyncClient(timeout=30, follow_redirects=False) as client:
            response = await client.post(
                f"https://almsearch.dev.azure.com/{organization}/_apis/search/codesearchresults",
                params={"api-version": "7.1"},
                headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
                json=payload,
            )
    except httpx.RequestError as error:
        raise CodeSearchError(f"Azure DevOps ({organization}) could not be reached. Try again.") from error
    if response.status_code in (401, 403):
        raise CodeSearchError(f"Azure DevOps denied access to {organization}. Run az login and check your organization permissions.")
    if response.status_code != 200:
        raise CodeSearchError(f"Azure DevOps ({organization}) returned HTTP {response.status_code}.")
    try:
        body = response.json()
        if not isinstance(body["results"], list) or type(body["count"]) is not int:
            raise ValueError()
        info = body.get("infoCode", 0)
        if info in FATAL_INFO_CODES:
            raise CodeSearchError(
                f"Azure DevOps ({organization}): {FATAL_INFO_CODES[info]} Refine the query and try again."
            )
        warning = _describe(organization, info) if info else ""
        results = []
        for match in body["results"]:
            project, repo = match["project"], match["repository"]
            path, file = match["path"], match["fileName"]
            if not all(isinstance(value, str) and value for value in (project["name"], repo["name"], path, file)):
                raise ValueError()
            versions = match.get("versions") or []
            branch = versions[0].get("branchName", "") if versions else ""
            base = f"https://dev.azure.com/{organization}/{quote(project['name'], safe='')}"
            if repo.get("type", "git") == "tfvc":
                url = base + "/_versionControl?" + urlencode({"path": path})
            else:
                url = base + "/_git/" + quote(repo["name"], safe="") + "?" + urlencode(
                    {"path": path, **({"version": "GB" + branch} if branch else {})}
                )
            fragments = match.get("matches") or {}
            snippet = "\n".join(
                part["content"] for parts in fragments.values() if isinstance(parts, list)
                for part in parts if isinstance(part, dict) and isinstance(part.get("content"), str)
            )
            results.append({"id": url, "organization": organization, "project": project["name"],
                            "repository": repo["name"], "file": file, "path": path,
                            "branch": branch, "url": url, "snippet": snippet})
        return {"results": results, "total": body["count"], "warning": warning}
    except (ValueError, TypeError, KeyError, AttributeError, IndexError) as error:
        raise CodeSearchError(f"Azure DevOps ({organization}) returned an unexpected search response.") from error


async def search_code(config: LauncherConfig, query: str, skip: int = 0, top: int = 10):
    organizations = sorted({ado_organization(url) for url in config.adoOrganizations}
                           | {ado_organization(repo.adoUrl) for repo in config.repositories})
    # With nothing configured, fall back to the deployment's default organization if it has
    # one, and otherwise say plainly what is missing rather than searching nowhere.
    project = "" if organizations else DEFAULT_PROJECT
    scope = organizations or ([DEFAULT_ORGANIZATION] if DEFAULT_ORGANIZATION else [])
    if not query.strip():
        return {"results": [], "total": 0, "hasMore": False, "organizations": scope,
                "warnings": [], "source": "Live"}
    if not scope:
        raise CodeSearchError(NOTHING_CONFIGURED)
    try:
        token = await azure_auth.access_token(RESOURCE)
    except azure_auth.AzureAuthError as error:
        raise CodeSearchError(str(error)) from error
    pages = await asyncio.gather(
        *(_search(org, query.strip(), skip, top, token, project) for org in scope),
        return_exceptions=True,
    )
    failures = [page for page in pages if isinstance(page, BaseException)]
    for failure in failures:
        if not isinstance(failure, CodeSearchError):
            raise failure
    succeeded = [page for page in pages if not isinstance(page, BaseException)]
    if not succeeded:
        raise failures[0]
    warnings = [page["warning"] for page in succeeded if page["warning"]]
    warnings += [str(failure) for failure in failures]
    return {
        "results": [result for page in succeeded for result in page["results"]],
        "total": sum(page["total"] for page in succeeded),
        "hasMore": any(skip + top < page["total"] for page in succeeded),
        "organizations": scope, "warnings": warnings, "source": "Live",
    }


async def search_page(config: LauncherConfig, query: str, skip: int = 0, top: int = 5):
    """Globally page disjoint repository/organization streams, priorities first."""
    organizations = sorted({ado_organization(url) for url in config.adoOrganizations}
                           | {ado_organization(repo.adoUrl) for repo in config.repositories})
    scope = organizations or ([DEFAULT_ORGANIZATION] if DEFAULT_ORGANIZATION else [])
    if not scope and not config.repositories:
        raise CodeSearchError(NOTHING_CONFIGURED)
    priorities = [next((repo for repo in config.repositories if repo.alias == alias), None)
                  for alias in config.preferences.priorityRepos]
    streams = []
    excluded: dict[str, list[str]] = {}
    for repo in priorities:
        if repo is None:
            continue
        org = ado_organization(repo.adoUrl)
        parts = [unquote(part) for part in urlsplit(repo.adoUrl).path.split("/") if part]
        project, name = parts[-3], parts[-1]
        streams.append((org, query, project, name))
        excluded.setdefault(org, []).append(name)
    for org in scope:
        exclusions = " ".join('-repo:"' + name.replace('"', '\\"') + '"' for name in excluded.get(org, []))
        streams.append((org, f"{query} {exclusions}".strip(), "" if organizations else DEFAULT_PROJECT, ""))
    try:
        token = await azure_auth.access_token(RESOURCE)
    except azure_auth.AzureAuthError as error:
        raise CodeSearchError(str(error)) from error
    counts = await asyncio.gather(*(_search(org, text, 0, 1, token, project, repo)
                                   for org, text, project, repo in streams), return_exceptions=True)
    failures = [value for value in counts if isinstance(value, BaseException)]
    for failure in failures:
        if not isinstance(failure, CodeSearchError):
            raise failure
    if len(failures) == len(counts):
        raise failures[0]
    warnings = [str(value) for value in failures]
    total = sum(value["total"] for value in counts if isinstance(value, dict))
    results, offset = [], skip
    for stream, count in zip(streams, counts):
        if not isinstance(count, dict):
            continue
        if count["warning"]:
            warnings.append(count["warning"])
        if offset >= count["total"]:
            offset -= count["total"]
            continue
        if len(results) >= top:
            break
        org, text, project, repo = stream
        try:
            page = await _search(org, text, offset, top - len(results), token, project, repo)
            results.extend(page["results"])
            offset = 0
        except CodeSearchError as error:
            warnings.append(str(error))
    return {"results": results, "total": total, "hasMore": skip + top < total,
            "organizations": scope, "warnings": list(dict.fromkeys(warnings)), "source": "Live"}
