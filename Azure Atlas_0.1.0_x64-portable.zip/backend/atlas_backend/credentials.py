"""Atlas-owned credentials in Windows Credential Manager, never in configuration files."""
from __future__ import annotations

import ctypes
import json
import sys
from ctypes import wintypes


class CredentialError(RuntimeError):
    pass


class Credential(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD), ("Type", wintypes.DWORD), ("TargetName", wintypes.LPWSTR),
        ("Comment", wintypes.LPWSTR), ("LastWritten", wintypes.FILETIME),
        ("CredentialBlobSize", wintypes.DWORD), ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
        ("Persist", wintypes.DWORD), ("AttributeCount", wintypes.DWORD), ("Attributes", ctypes.c_void_p),
        ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR),
    ]


def _api():
    if sys.platform != "win32":
        raise CredentialError("Device sign-in requires Windows Credential Manager.")
    api = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    api.CredReadW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.POINTER(Credential))]
    api.CredReadW.restype = wintypes.BOOL
    api.CredWriteW.argtypes = [ctypes.POINTER(Credential), wintypes.DWORD]
    api.CredWriteW.restype = wintypes.BOOL
    api.CredFree.argtypes = [ctypes.c_void_p]
    api.CredFree.restype = None
    return api


def read(provider: str) -> dict | None:
    if sys.platform != "win32":
        return None
    api = _api()
    pointer = ctypes.POINTER(Credential)()
    if not api.CredReadW(f"AzureAtlas/{provider}", 1, 0, ctypes.byref(pointer)):
        code = ctypes.get_last_error()
        if code == 1168:
            return None
        raise CredentialError(f"Windows Credential Manager could not read the credential (error {code}).")
    try:
        credential = pointer.contents
        return json.loads(ctypes.string_at(credential.CredentialBlob, credential.CredentialBlobSize).decode("utf-8"))
    except (ValueError, UnicodeError) as error:
        raise CredentialError("The saved credential could not be read. Sign in again.") from error
    finally:
        api.CredFree(pointer)


def write(provider: str, value: dict) -> None:
    api = _api()
    raw = json.dumps(value).encode("utf-8")
    blob = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    credential = Credential(Type=1, TargetName=f"AzureAtlas/{provider}", CredentialBlobSize=len(raw),
                            CredentialBlob=blob, Persist=2, UserName=value.get("account", "Azure Atlas"))
    if not api.CredWriteW(ctypes.byref(credential), 0):
        raise CredentialError(f"Windows Credential Manager could not save the credential (error {ctypes.get_last_error()}).")
