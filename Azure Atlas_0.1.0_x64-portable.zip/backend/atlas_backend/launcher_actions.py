"""Resolve launch actions before execution; user arguments are data, not shell syntax."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from urllib.parse import quote

from pydantic import Field

from .launcher_config import (
    ConfigError, LauncherConfig, Model, PLACEHOLDER, Shortcut, https_url, local_path,
    resolve_repository, validate_shortcut,
)


class CommandRequest(Model):
    command: str
    text: str = Field(default="", max_length=8000)


class ExecuteRequest(CommandRequest):
    fingerprint: str
    approve: bool = False


class PreviewRequest(Model):
    shortcut: Shortcut
    text: str = Field(default="", max_length=8000)


class CodeOpenRequest(Model):
    url: str
    repository: str
    path: str


def open_code(config: LauncherConfig, request: CodeOpenRequest) -> None:
    from pathlib import Path
    from urllib.parse import urlsplit, unquote
    destination = urlsplit(https_url(request.url))
    repo = next((repo for repo in config.repositories
                 if urlsplit(repo.adoUrl).hostname == destination.hostname
                 and unquote(urlsplit(repo.adoUrl).path).casefold() == unquote(destination.path).casefold()), None)
    if repo is None:
        raise ConfigError("Add this repository's local path under Preferences → Repositories to open it in VS Code.")
    root = local_path(repo.path, directory=True).resolve()
    path = (root / request.path.lstrip("/\\")).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise ConfigError("The matching file is not present inside the configured repository.")
    if sys.platform != "win32":
        raise ConfigError("Opening local source files requires Windows.")
    try:
        os.startfile("vscode://file/" + quote(str(Path(path)).replace("\\", "/"), safe="/:"))
    except OSError as error:
        raise ConfigError(f"Could not open VS Code: {error}") from error


class Action(Model):
    kind: str
    target: str
    arguments: list[str] = Field(default_factory=list)
    cwd: str | None = None
    fingerprint: str = ""
    requiresApproval: bool = False


_approvals: set[str] = set()


def tokens(text: str) -> list[str]:
    """Windows paths retain backslashes; single/double quotes group arguments."""
    if "\x00" in text:
        raise ConfigError("Command arguments cannot contain null characters.")
    result, current = [], []
    quoted = None
    started = False
    for char in text:
        if quoted:
            if char == quoted:
                quoted = None
            else:
                current.append(char)
        elif char in "\"'":
            quoted = char
            started = True
        elif char.isspace():
            if started:
                result.append("".join(current))
                current, started = [], False
        else:
            current.append(char)
            started = True
    if quoted:
        raise ConfigError("Close the quoted argument before running this command.")
    if started:
        result.append("".join(current))
    return result


def values(shortcut: Shortcut, text: str) -> dict[str, str]:
    words = tokens(text)
    result = dict.fromkeys(shortcut.arguments + shortcut.flags, "")
    position, index = 0, 0
    used_flags = set()
    while index < len(words):
        word = words[index]
        if word.startswith("--"):
            name, equal, value = word[2:].partition("=")
            if name not in shortcut.flags or name in used_flags:
                raise ConfigError(f"Unknown or repeated flag --{name}. Available flags: {', '.join(shortcut.flags) or 'none'}.")
            used_flags.add(name)
            if not equal:
                if index + 1 < len(words) and not words[index + 1].startswith("--"):
                    index += 1
                    value = words[index]
                else:
                    value = "true"
            result[name] = value
        else:
            if position >= len(shortcut.arguments):
                raise ConfigError("Too many positional arguments. Quote values containing spaces.")
            result[shortcut.arguments[position]] = word
            position += 1
        index += 1
    return result


def ps_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def shortcut_action(shortcut: Shortcut, text: str) -> Action:
    shortcut = validate_shortcut(shortcut)
    supplied = values(shortcut, text)
    def substitute(template: str, encode=lambda value: value) -> str:
        return PLACEHOLDER.sub(lambda match: encode(supplied[match[1]]), template)
    if shortcut.action == "application":
        parts = tokens(shortcut.template)
        if not parts:
            raise ConfigError("An application executable is required.")
        # Split before substitution, so an argument can never become another switch.
        action = Action(kind="application", target=substitute(parts[0]),
                        arguments=[substitute(part) for part in parts[1:]])
    elif shortcut.action == "shell":
        # Placeholders must be whole PowerShell expressions, not embedded inside quotes.
        quote_state = None
        previous = 0
        for match in PLACEHOLDER.finditer(shortcut.template):
            for char in shortcut.template[previous:match.start()]:
                if char in "\"'":
                    quote_state = None if quote_state == char else char if quote_state is None else quote_state
            if quote_state or (match.start() and shortcut.template[match.start() - 1] not in " \t\r\n(=,"):
                raise ConfigError("Use shell placeholders as unquoted, standalone values, for example Write-Output {topic}.")
            if match.end() < len(shortcut.template) and shortcut.template[match.end()] not in " \t\r\n);,|":
                raise ConfigError("Shell placeholders must be standalone values.")
            previous = match.end()
        action = Action(kind="shell", target=substitute(shortcut.template, ps_literal))
    else:
        action = Action(kind=shortcut.action, target=substitute(
            shortcut.template, (lambda value: quote(value, safe="")) if shortcut.action == "url" else (lambda value: value)
        ))
    validate_action(action)
    return action


def validate_action(action: Action) -> None:
    if action.kind == "url":
        https_url(action.target)
    elif action.kind == "path":
        path = local_path(action.target)
        if path.is_file() and path.suffix.lower() in {".exe", ".com", ".cmd", ".bat", ".ps1", ".lnk", ".url", ".vbs", ".js", ".hta", ".msc", ".reg"}:
            raise ConfigError("Use an application or shell action for executable files and shortcuts.")
    elif action.kind == "application":
        executable = shutil.which(action.target)
        if not executable and not (os.path.isabs(action.target) and os.path.isfile(action.target)):
            raise ConfigError(f"Application not found: {action.target}. Use its executable path or add it to PATH.")
        name, extension = os.path.splitext(os.path.basename(executable or action.target))
        if extension.lower() in {".cmd", ".bat", ".ps1", ".lnk"} or name.lower() in {
            "pwsh", "powershell", "cmd", "wscript", "cscript", "mshta", "bash", "sh",
            "python", "pythonw", "py", "node",
        }:
            raise ConfigError("Scripts require the shell action type and explicit approval.")


def resolve(config: LauncherConfig, request: CommandRequest) -> Action:
    command = request.command.lower().removeprefix("/")
    if command in {"repo", "ado", "copilot"}:
        repo = resolve_repository(config, request.text) if request.text.strip() or command != "copilot" else None
        if repo and command != "ado":
            local_path(repo.path, directory=True)
        if command == "ado":
            action = Action(kind="url", target=repo.adoUrl)
        elif command == "repo":
            # VS Code's registered URL protocol avoids executing its code.cmd shim.
            action = Action(kind="vscode", target="vscode://file/" + quote(repo.path.replace("\\", "/"), safe="/:"))
        else:
            action = Action(kind="copilot", target="copilot", cwd=repo.path if repo else None)
    elif command == "icm":
        if request.text.strip():
            raise ConfigError("Use /icm without arguments to open the team queue.")
        if not config.icmQueriesUrl:
            raise ConfigError("Add your team queue under Preferences → IcM first.")
        action = Action(kind="browser-window", target=config.icmQueriesUrl)
    else:
        shortcut = next((item for item in config.shortcuts if item.command == command), None)
        if shortcut is None:
            raise ConfigError(f"Unknown command /{command}. Choose a command from autocomplete.")
        action = shortcut_action(shortcut, request.text)
    identity = json.dumps({"action": action.model_dump(exclude={"fingerprint", "requiresApproval"}),
                           "command": command}, sort_keys=True)
    action.fingerprint = hashlib.sha256(identity.encode()).hexdigest()
    action.requiresApproval = action.kind == "shell" and action.fingerprint not in _approvals
    return action


def powershell(script: str, cwd: str | None = None, env: dict[str, str] | None = None) -> None:
    executable = shutil.which("pwsh.exe") or shutil.which("powershell.exe")
    if not executable:
        raise ConfigError("PowerShell was not found. Install PowerShell or add it to PATH.")
    encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    # Leave standard handles unset so CREATE_NEW_CONSOLE supplies interactive console
    # handles. Redirecting them to NUL makes Copilot think it has no interactive terminal.
    subprocess.Popen([executable, "-NoLogo", "-NoProfile", "-NoExit", "-EncodedCommand", encoded],
                     cwd=cwd, env=env, creationflags=subprocess.CREATE_NEW_CONSOLE, close_fds=True)


def browser_window(url: str) -> None:
    import winreg

    # ShellExecute's "open" may reuse an existing tab; supported browsers expose an
    # explicit new-window switch. Resolve the user's association rather than choosing Edge.
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice") as key:
            prog_id = winreg.QueryValueEx(key, "ProgId")[0]
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, prog_id + r"\shell\open\command") as key:
            command = os.path.expandvars(winreg.QueryValue(key, None))
        match = re.match(r'^"([^"]+)"|^(\S+)', command)
        executable = (match[1] or match[2]) if match else ""
        browser = os.path.basename(executable).lower()
        if browser not in {"msedge.exe", "chrome.exe", "firefox.exe", "brave.exe", "vivaldi.exe"}:
            raise ConfigError("Opening a new browser window requires Edge, Chrome, Firefox, Brave or Vivaldi as the default HTTPS browser.")
        switch = "-new-window" if browser == "firefox.exe" else "--new-window"
        subprocess.Popen([executable, switch, url], stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as error:
        raise ConfigError(f"Could not open the default browser in a new window: {error}") from error


def execute(config: LauncherConfig, request: ExecuteRequest) -> Action:
    action = resolve(config, request)
    if action.fingerprint != request.fingerprint:
        raise ConfigError("The action changed. Preview it again before executing.")
    if action.requiresApproval and not request.approve:
        raise ConfigError("Approve this shell command before its first execution.")
    if sys.platform != "win32":
        raise ConfigError("Local launch actions currently require Windows.")
    try:
        if action.kind == "copilot":
            if not shutil.which("copilot"):
                raise ConfigError("Copilot CLI was not found. Install it and add it to PATH.")
            from . import credentials
            try:
                credential = credentials.read("copilot")
            except credentials.CredentialError as error:
                raise ConfigError(str(error)) from error
            if credential and credential.get("token"):
                powershell("copilot", action.cwd, {**os.environ, "COPILOT_GITHUB_TOKEN": credential["token"]})
            else:
                powershell("copilot", action.cwd)
        elif action.kind == "shell":
            powershell(action.target)
        elif action.kind == "application":
            subprocess.Popen([action.target, *action.arguments], stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif action.kind == "browser-window":
            browser_window(action.target)
        else:
            os.startfile(action.target)
    except OSError as error:
        raise ConfigError(f"Could not launch the action: {error}") from error
    if action.kind == "shell":
        _approvals.add(action.fingerprint)
    return action
