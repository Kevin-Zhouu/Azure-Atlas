"""Authenticated EngHub search and page metadata retrieval."""

from html.parser import HTMLParser
from urllib.parse import urlsplit
from datetime import datetime, timezone, timedelta

import httpx

from . import azure_auth
from .launcher_config import Preferences

RESOURCE = "api://engineeringhubprod.ame.gbl"
BASE_URL = "https://api.eng.ms"


class EngHubError(Exception):
    pass


class _Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def plain_text(value):
    parser = _Text()
    parser.feed(value or "")
    return "".join(parser.parts)


def page_route(value: str) -> str:
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc:
        if parsed.scheme != "https" or parsed.netloc != "eng.ms":
            raise ValueError("Use an https://eng.ms document URL or route.")
    if not parsed.path.startswith("/") or parsed.path.startswith("//"):
        raise ValueError("An absolute EngHub document route is required.")
    return parsed.path


async def _request(method: str, path: str, **kwargs):
    try:
        token = await azure_auth.access_token(RESOURCE)
        async with httpx.AsyncClient(timeout=30, follow_redirects=False) as client:
            response = await client.request(
                method, BASE_URL + path,
                headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
                **kwargs,
            )
    except azure_auth.AzureAuthError as error:
        raise EngHubError(str(error)) from error
    except httpx.RequestError as error:
        raise EngHubError("EngHub could not be reached. Try again.") from error
    if response.status_code in (401, 403):
        raise EngHubError("EngHub denied access. Check your Azure CLI sign-in and document permissions.")
    if response.is_error or response.is_redirect:
        raise EngHubError(f"EngHub returned HTTP {response.status_code}. Try again.")
    try:
        body = response.json()
        if not isinstance(body, dict):
            raise ValueError()
        return body
    except ValueError as error:
        raise EngHubError("EngHub returned an unexpected response.") from error


async def search_guides(query: str, skip: int = 0, top: int = 10, preferences: Preferences | None = None):
    if not query.strip():
        return {"strong": [], "related": [], "total": 0, "source": "Live"}
    filter_text = "docType ne 'BestBet'"
    if preferences and preferences.staleness:
        threshold = (datetime.now(timezone.utc) - timedelta(days=preferences.staleness)).isoformat()
        filter_text += f" and updtOn ge {threshold}"
    body = await _request("POST", "/api/search", json={
        "count": True, "filter": filter_text,
        "highlight": ["name", "title", "desc", "content", "path"],
        "queryType": "Simple", "search": query.strip(), "skip": skip, "top": top,
    })
    if not isinstance(body.get("values"), list) or not isinstance(body.get("count"), int):
        raise EngHubError("EngHub returned an unexpected search response.")
    guides = []
    try:
        for match in body["values"]:
            document = match["document"]
            routes = document.get("routes") or []
            if not routes:
                continue
            route = page_route(routes[0])
            highlights = match.get("highlights") or {}
            excerpt = " ... ".join(highlights.get("content") or highlights.get("desc") or [])
            content = document.get("content") or ""
            guides.append({
                "id": document["id"], "title": document.get("title") or document.get("name") or route,
                "path": route, "url": "https://eng.ms" + route,
                "classification": "Search match", "source": "Live",
                "excerpt": plain_text(excerpt or document.get("desc") or content[:600]),
                "content": content, "reason": "Ranked by EngHub search.",
                "keywords": document.get("keywords") or [],
                "updated": document.get("updtOn") or "", "steps": [],
            })
    except (KeyError, TypeError, ValueError, AttributeError) as error:
        raise EngHubError("EngHub returned an unexpected search result.") from error
    if preferences:
        if preferences.preferTeam:
            targets = [url for url in [preferences.teamSpaceUrl, preferences.teamTsgUrl] if url]
            guides.sort(key=lambda guide: not any(
                guide["url"].startswith(url) or url in guide["content"] for url in targets
            ))
        strong, related = [], []
        terms = query.casefold().split()
        for guide in guides:
            target = strong if any(term in (guide["title"] + " " + guide["excerpt"]).casefold() for term in terms) else related
            guide["classification"] = "Title match" if target is strong else "Related recommendation"
            target.append(guide)
        return {"strong": strong, "related": related if preferences.includeRelated else [], "total": body["count"], "source": "Live"}
    return {"strong": guides, "related": [], "total": body["count"], "source": "Live"}


async def get_page(route: str):
    route = page_route(route)
    body = await _request("GET", "/api/v1.0/PageFlow/GetByRoute", params={"route": route})
    documentation = body.get("documentation")
    if not isinstance(documentation, dict):
        raise EngHubError("EngHub returned no document metadata for this route.")
    return {
        "url": "https://eng.ms" + route,
        "repositoryUrl": documentation.get("repositoryUrl"),
        "branch": documentation.get("repositoryBranch"),
        "updated": documentation.get("updtOn"), "source": "Live",
    }