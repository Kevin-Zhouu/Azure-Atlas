"""Repository, guide and tool lookup over the local fixture index.

These are representative engineering results, not a production index. The API says so through
the ``X-Atlas-Source: Demo`` header on every response, and the launcher labels them accordingly.
"""

from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

FIXTURES = Path(__file__).parent / "data" / "fixtures.json"

#: Exact matches rank above related ones, so the result an engineer meant is first.
RANK = {
    "Exact configuration": 0,
    "Exact symbol": 1,
    "Filename match": 2,
    "Related reference": 3,
}


@lru_cache(maxsize=1)
def _index() -> dict[str, list[dict[str, Any]]]:
    with FIXTURES.open(encoding="utf-8") as handle:
        data = json.load(handle)
    return {
        "repositories": data.get("repositories", []),
        "guides": data.get("guides", []),
        "tools": data.get("tools", []),
    }


def repositories() -> list[dict[str, Any]]:
    return _index()["repositories"]


def guides() -> list[dict[str, Any]]:
    return _index()["guides"]


def tools() -> list[dict[str, Any]]:
    return _index()["tools"]


def search_repositories(query: str) -> list[dict[str, Any]]:
    text = query.strip().lower()
    if not text:
        return []
    matches = [
        item
        for item in repositories()
        if any(
            text in str(item.get(field, "")).lower()
            for field in ("term", "path", "repository", "snippet")
        )
    ]
    return sorted(matches, key=lambda item: RANK.get(item.get("classification", ""), 99))


def search_guides(query: str, broaden: bool = False) -> dict[str, list[dict[str, Any]]]:
    text = query.strip().lower()
    if not text:
        return {"strong": [], "related": []}
    strong = [
        guide
        for guide in guides()
        if guide.get("classification") != "Related recommendation"
        and (
            text in guide.get("title", "").lower()
            or text in guide.get("excerpt", "").lower()
            or text in [keyword.lower() for keyword in guide.get("keywords", [])]
        )
    ]
    strong_ids = {guide.get("id") for guide in strong}
    words = [word for word in re.split(r"\s+", text) if len(word) > 2]
    related = [
        guide
        for guide in guides()
        if guide.get("id") not in strong_ids
        and any(
            word
            in f"{guide.get('title', '')} {guide.get('excerpt', '')} "
            f"{' '.join(guide.get('keywords', []))}".lower()
            for word in words
        )
    ]
    # Weak suggestions are withheld until there is a strong result to sit beneath, or the
    # engineer has explicitly asked to broaden the search.
    return {"strong": strong, "related": related if (strong or broaden) else []}


def search_tools(query: str) -> list[dict[str, Any]]:
    words = [word for word in re.split(r"\s+", query.strip().lower()) if word]
    if not words:
        return tools()
    return [
        tool
        for tool in tools()
        if all(
            word
            in f"{tool.get('name', '')} {tool.get('category', '')} "
            f"{tool.get('description', '')}".lower()
            for word in words
        )
    ]


def validate_destination(raw: str) -> str:
    """Reject anything that is not a plain HTTPS destination before the shell opens it."""
    parts = urlsplit(raw.strip())
    if parts.scheme != "https" or not parts.netloc or parts.username or parts.password:
        raise ValueError("Use an HTTPS destination without embedded credentials.")
    return parts.geturl()
