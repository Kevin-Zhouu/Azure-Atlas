"""Schema-aware natural-language to KQL generation.

An engineer describes what they want to see; this turns that into a query they can read,
edit and run. Generation is grounded on the live schema of the database they have selected,
on the knowledge items they configured under Preferences → Kusto, and on any local grounding
notes they dropped into their own context directory (see :func:`local_grounding`).

The grounding is not decoration. A schema gives the model table and column names, but not the
values inside them: asked for failed operations, a model will happily invent a status literal
that matches nothing. Writing the real values down once, as a knowledge item or a grounding
file, is what makes generated queries return rows.

Nothing here runs a query. The engineer reviews what came back and presses Run.
"""

from __future__ import annotations

import functools
import os
import pathlib

from . import copilot_llm, kusto, launcher_config
from .models import GeneratedQuery, KustoGenerationRequest, QueryRequest

#: Optional, entirely user-owned. Nothing ships here; Atlas only reads what an engineer puts
#: in it, so no team's internal schema travels with the application.
def context_dir() -> pathlib.Path:
    override = os.environ.get("ATLAS_CONTEXT_DIR", "")
    return pathlib.Path(override) if override else launcher_config.config_path().parent / "context"

#: Long enough to be unambiguous, short enough that it costs no meaningful time to send.
SYSTEM_PROMPT = """You write read-only Kusto (KQL) queries for Azure engineers.

Answer with a single minified JSON object and nothing else. No prose, no Markdown fences.
Shape: {"title": "short title", "explanation": "one sentence", "query": "the KQL"}

Rules:
- Use only the tables and columns in the schema supplied with the request.
- Read-only queries only. Never emit a management command beginning with a dot.
- Always bound the query with an explicit time filter when a timestamp column exists.
- Put each operator on its own line beginning with a pipe.
- Prefer summarize over returning raw rows when the request asks for counts or trends.
- Answer exactly what was asked. Do not add extra aggregations, columns or filters the
  engineer did not ask for; a shorter query is easier to read and to edit.
- Keep the explanation to one short sentence.
- Add a render directive only when the engineer asked for a chart.
- Treat every request as independent. Ignore anything asked earlier in this conversation."""


@functools.cache
def local_grounding(database: str) -> str:
    """Grounding notes an engineer keeps for a database, if they keep any.

    ``<context>/<database>.md`` applies to one database and ``<context>/default.md`` to all
    of them. Both are optional; the common case is that the directory does not exist.
    """
    directory = context_dir()
    parts = []
    for name in ("default", database.strip().lower()):
        if not name:
            continue
        try:
            parts.append((directory / f"{name}.md").read_text(encoding="utf-8").strip())
        except OSError:
            continue
    return "\n\n---\n\n".join(part for part in parts if part)


def system_prompt_for(database: str) -> str:
    """The system prompt for a database, with the engineer's own grounding when they have any."""
    rules = local_grounding(database)
    return f"{SYSTEM_PROMPT}\n\n---\n\n{rules}" if rules else SYSTEM_PROMPT


def _schema_text(schema) -> str:
    return "\n".join(
        f"{table.name}({', '.join(f'{column.name}:{column.type}' for column in table.columns)})"
        for table in schema.tables
    )


def _knowledge_text(schema, preferences) -> str:
    """The knowledge items scoped to this database, as one block."""
    if not preferences.useKnowledge:
        return ""
    return "\n\n".join(
        f"{item.type}: {item.name}\n{item.content}"
        for item in preferences.knowledge
        if (not item.cluster or item.cluster.rstrip("/") == schema.cluster.rstrip("/"))
        and (not item.database or item.database.casefold() == schema.database.casefold())
    )


async def session_prompt(cluster: str, database: str) -> tuple[str, object]:
    """Build the system prompt for a database, and return it with the schema it describes.

    Everything that is fixed for a database — the rules, the schema, the knowledge items and
    the engineer's notes — belongs here rather than in each question. A system prompt is set
    once per session; a user message is repeated, kept in the conversation history and re-read
    on every later turn, so putting the schema there made each request carry another copy of
    it. Measured over five turns, moving it cut the first generation from 8.8s to 5.6s.

    It also means prewarming and generating build the same prompt, which is what lets the
    engineer's first real request land on the session that was warmed for it.
    """
    schema = await kusto.database_schema(cluster, database)
    if not schema.tables:
        raise kusto.KustoError("The selected database has no visible tables.")
    preferences = launcher_config.load_config().preferences
    knowledge = _knowledge_text(schema, preferences)
    if len(knowledge) > 240_000:
        raise kusto.KustoError(
            "Knowledge for this database exceeds 60,000 estimated tokens. "
            "Reduce or narrow its scope in Preferences."
        )
    notes = preferences.modelNotes if preferences.useKnowledge else ""
    sections = [
        system_prompt_for(schema.database),
        f"Cluster: {schema.cluster}\nDatabase: {schema.database}\nSchema:\n{_schema_text(schema)}",
    ]
    if knowledge:
        sections.append(f"Knowledge for this database:\n{knowledge}")
    if notes:
        sections.append(f"Notes for the model:\n{notes}")
    return "\n\n---\n\n".join(sections), schema


async def prewarm(cluster: str, database: str) -> None:
    """Warm the model session and the schema for a database before it is asked about."""
    try:
        prompt, _ = await session_prompt(cluster, database)
    except Exception:  # noqa: BLE001 - warming must never surface an error of its own
        return
    await copilot_llm.prewarm(prompt)


async def generate_query(request: KustoGenerationRequest) -> GeneratedQuery:
    prompt, schema = await session_prompt(request.cluster, request.database)
    refinement = (
        f"Current query to revise (preserve its intent and comments):\n{request.current_query}\n"
        "Rewrite this query to apply the engineer's refinement, not a new query from scratch.\n\n"
    ) if request.current_query else ""
    # Generation runs as the engineer types, so only their latest question is worth answering;
    # coalescing abandons the earlier ones rather than making them queue ahead of it.
    content = await copilot_llm.complete(
        prompt, f"{refinement}Engineer request:\n{request.prompt}", coalesce=True
    )

    parsed = copilot_llm.parse_json_object(content)
    try:
        title = str(parsed["title"]).strip()
        explanation = str(parsed["explanation"]).strip()
        # check_query is the same guard the Run path uses, so a generated query never reaches
        # the cluster on terms the engineer's own typing would not have been held to.
        query = kusto.check_query(str(parsed["query"]))
    except (KeyError, AttributeError, TypeError) as error:
        raise copilot_llm.CopilotError(
            "Copilot returned an answer Atlas could not read. Try rephrasing the request."
        ) from error

    return GeneratedQuery(
        title=title or "Generated query",
        explanation=explanation,
        request=QueryRequest(
            cluster=schema.cluster,
            database=schema.database,
            query=query,
            mode="live",
        ),
    )
