"""The local HTTP service the Azure Atlas launcher talks to.

The launcher owns no integration logic of its own. It renders, and asks this service for
repository matches, troubleshooting guidance, registered tools and Kusto results. Everything
here is loopback-only and scoped to the engineer already signed in on the machine.
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Query, Response, status
from fastapi.middleware.cors import CORSMiddleware

from . import (
    __version__,
    agents,
    azure_auth,
    accounts,
    credentials,
    code_search,
    copilot_llm,
    enghub,
    generation,
    incidents,
    kusto,
    knowledge,
    launcher_actions,
    launcher_config,
    search,
)
from .config import settings
from .models import (
    AuthStatus,
    CopilotStatus,
    DatabaseSchema,
    DeviceLogin,
    GeneratedQuery,
    GuideResults,
    Health,
    IncidentSummary,
    KustoGenerationRequest,
    PrewarmRequest,
    QueryRequest,
    QueryResult,
)
from .security import require_local_action, require_token

logger = logging.getLogger("atlas")

#: Applied to every fixture-backed response so the launcher never has to guess what is real.
DEMO_HEADER = {"X-Atlas-Source": "Demo"}


async def _warm_target() -> tuple[str, str]:
    """The cluster and database the launcher will open on.

    Warming has to use the same target the launcher shows, because the schema is part of
    the model session's system prompt: warming a different database builds a session the
    engineer's first request then has to throw away.
    """
    try:
        preferences = launcher_config.load_config().preferences
        clusters = preferences.clusters
        chosen = next((c for c in clusters if c.url == preferences.defaultCluster), None) or (
            clusters[0] if clusters else None
        )
        if chosen and chosen.url and chosen.database:
            return chosen.url, chosen.database
    except Exception:  # noqa: BLE001 - an unreadable config must not stop start-up
        logger.debug("Could not read the configured default cluster", exc_info=True)
    return settings.default_cluster, settings.default_database


async def _warm() -> None:
    cluster, database = await _warm_target()
    await generation.prewarm(cluster, database)


@asynccontextmanager
async def lifespan(_: FastAPI):
    logger.info("Atlas backend listening on %s", settings.url)
    # Copilot's runtime and a Kusto schema both take seconds to acquire the first time.
    # Doing it here means the engineer's first generation pays neither cost. It runs
    # detached because the service must answer /health immediately either way.
    warm = None if settings.demo_mode else asyncio.create_task(_warm())
    schema_refresh = None if settings.demo_mode else asyncio.create_task(knowledge.refresh_loop())
    try:
        yield
    finally:
        if warm:
            warm.cancel()
        if schema_refresh:
            schema_refresh.cancel()
        await accounts.cancel("azure")
        await accounts.cancel("copilot")
        await copilot_llm.shutdown()
        await kusto.shutdown()


app = FastAPI(
    title="Azure Atlas backend",
    version=__version__,
    lifespan=lifespan,
    docs_url="/docs",
    openapi_url="/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.origins),
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)

guarded = [Depends(require_token)]


@app.get("/health", response_model=Health)
async def health() -> Health:
    """Readiness probe. Unauthenticated by design so the launcher can detect the service
    before it has a token, and deliberately free of account detail."""
    return Health(
        version=__version__,
        kusto="Live",
        guides="Live",
        auth_required=settings.auth_required,
    )


@app.get("/kusto/auth", response_model=AuthStatus, dependencies=guarded)
async def kusto_auth() -> AuthStatus:
    return await azure_auth.auth_status()


@app.get("/auth/status", response_model=AuthStatus, dependencies=guarded)
async def auth_status() -> AuthStatus:
    return await azure_auth.auth_status()


@app.post("/auth/login", dependencies=[*guarded, Depends(require_local_action)])
async def azure_login():
    try:
        return await accounts.begin("azure")
    except (accounts.AccountError, credentials.CredentialError) as error:
        raise HTTPException(400, str(error)) from error


@app.post("/auth/login/cancel", dependencies=[*guarded, Depends(require_local_action)])
async def azure_cancel():
    await accounts.cancel("azure")
    return {"cancelled": True}


@app.post("/auth/logout", dependencies=[*guarded, Depends(require_local_action)])
async def azure_logout():
    try:
        await accounts.logout("azure")
        azure_auth._tokens.clear()
        return {"signedOut": True}
    except credentials.CredentialError as error:
        raise HTTPException(400, str(error)) from error


@app.get("/incident/{incident_id}", response_model=IncidentSummary, dependencies=guarded)
async def incident(incident_id: str) -> IncidentSummary:
    result = incidents.get_incident(incident_id)
    if result is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Incident was not found in the MVP scenario.")
    return result


@app.get("/code/search", dependencies=guarded)
async def code(
    response: Response, q: str = Query(min_length=1, max_length=2000),
    skip: int = Query(default=0, ge=0, le=1000), top: int = Query(default=10, ge=1, le=50),
):
    try:
        result = await code_search.search_page(launcher_config.load_config(), q, skip, top)
    except (code_search.CodeSearchError, launcher_config.ConfigError) as error:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, str(error)) from error
    response.headers["X-Atlas-Source"] = "Live"
    return result


@app.get("/settings/commands", dependencies=guarded)
def command_settings():
    try:
        return {"config": launcher_config.load_config(), "path": str(launcher_config.config_path())}
    except launcher_config.ConfigError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.get("/agents/status", response_model=agents.AgentStatus, dependencies=guarded)
def agent_status():
    return agents.status()


@app.post("/agents/resolve", response_model=agents.AgentLaunch, dependencies=[*guarded, Depends(require_local_action)])
def resolve_agent(request: dict[str, Any]):
    name = str(request.get("name") or "")
    prompt = str(request.get("prompt") or "")
    try:
        config = launcher_config.load_config()
        return agents.plain_terminal(config) if not name.strip() else agents.resolve(config, name, prompt)
    except launcher_config.ConfigError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.post("/code/open", dependencies=[*guarded, Depends(require_local_action)])
def open_code(request: launcher_actions.CodeOpenRequest):
    try:
        launcher_actions.open_code(launcher_config.load_config(), request)
        return {"opened": True}
    except launcher_config.ConfigError as error:
        raise HTTPException(400, str(error)) from error


@app.post("/settings/commands", dependencies=[*guarded, Depends(require_local_action)])
def save_command_settings(config: launcher_config.LauncherConfig):
    try:
        return {"config": launcher_config.save_config(config), "path": str(launcher_config.config_path())}
    except launcher_config.ConfigError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.post("/settings/validate", dependencies=[*guarded, Depends(require_local_action)])
def validate_command_settings(config: launcher_config.LauncherConfig):
    try:
        launcher_config.validate_config(config, check_paths=True)
        return {"valid": True}
    except launcher_config.ConfigError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.post("/commands/preview", dependencies=[*guarded, Depends(require_local_action)])
def preview_shortcut(request: launcher_actions.PreviewRequest):
    try:
        return launcher_actions.shortcut_action(request.shortcut, request.text)
    except launcher_config.ConfigError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.post("/commands/resolve", dependencies=[*guarded, Depends(require_local_action)])
def resolve_command(request: launcher_actions.CommandRequest):
    try:
        return launcher_actions.resolve(launcher_config.load_config(), request)
    except launcher_config.ConfigError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.post("/commands/execute", dependencies=[*guarded, Depends(require_local_action)])
def execute_command(request: launcher_actions.ExecuteRequest):
    try:
        action = launcher_actions.execute(launcher_config.load_config(), request)
        return {"message": "Opened " + action.target}
    except launcher_config.ConfigError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.post("/kusto/query", response_model=QueryResult, dependencies=guarded)
async def kusto_query(request: QueryRequest) -> QueryResult:
    try:
        return await kusto.run_query(request.cluster, request.database, request.query)
    except kusto.KustoError as error:
        # 400 rather than 500: these are all messages the engineer can act on.
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.post("/kusto/generate", response_model=GeneratedQuery, dependencies=guarded)
async def kusto_generate(request: KustoGenerationRequest) -> GeneratedQuery:
    try:
        return await generation.generate_query(request)
    except copilot_llm.Superseded as error:
        # The engineer kept typing and a newer question replaced this one. 409 rather than an
        # error the launcher would show: nothing went wrong, and the caller has moved on.
        raise HTTPException(
            status.HTTP_409_CONFLICT, "A newer request replaced this one."
        ) from error
    except kusto.KustoError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error
    except copilot_llm.CopilotError as error:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, str(error)) from error


@app.post("/kusto/prewarm", status_code=status.HTTP_202_ACCEPTED, dependencies=guarded)
async def kusto_prewarm(request: PrewarmRequest) -> dict[str, str]:
    """Warm the model session and schema for a database the engineer has just selected.

    Returns immediately: the point is to move waiting off the generation path, so making
    the caller wait here would defeat it.
    """
    asyncio.create_task(generation.prewarm(request.cluster, request.database))
    return {"status": "warming"}


@app.get("/copilot/status", response_model=CopilotStatus, dependencies=guarded)
async def copilot_status() -> CopilotStatus:
    """Whether query generation is available, and under which GitHub account."""
    if await copilot_llm.login_finished():
        # A device login that has exited stored its token outside this process; the runtime
        # has to be rebuilt before it will see it.
        await copilot_llm.refresh()
    state = await copilot_llm.auth()
    return CopilotStatus(
        available=state.available,
        signed_in=state.signed_in,
        account=state.account,
        method=state.method,
        model=copilot_llm.configured_model(),
        message=state.message,
    )


@app.post("/copilot/login", response_model=DeviceLogin, dependencies=[*guarded, Depends(require_local_action)])
async def copilot_login() -> DeviceLogin:
    """Begin a GitHub device sign-in and return the URL and code to show the engineer."""
    try:
        started = await accounts.begin("copilot")
    except (accounts.AccountError, credentials.CredentialError) as error:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, str(error)) from error
    return DeviceLogin(
        verification_uri=started["verificationUri"], user_code=started["userCode"]
    )


@app.post("/copilot/login/cancel", dependencies=[*guarded, Depends(require_local_action)])
async def copilot_login_cancel():
    await copilot_llm.cancel_device_login()
    await accounts.cancel("copilot")
    return {"cancelled": True}


@app.post("/copilot/logout", dependencies=[*guarded, Depends(require_local_action)])
async def copilot_logout():
    try:
        await accounts.logout("copilot")
        await copilot_llm.refresh()
        return {"signedOut": True}
    except credentials.CredentialError as error:
        raise HTTPException(400, str(error)) from error


@app.get("/copilot/models", dependencies=guarded)
async def copilot_models():
    try:
        return await copilot_llm.models()
    except copilot_llm.CopilotError as error:
        raise HTTPException(503, str(error)) from error


@app.get("/kusto/databases", dependencies=guarded)
async def kusto_databases(cluster: str = Query(min_length=1)) -> list[str]:
    try:
        return await kusto.list_databases(cluster)
    except kusto.KustoError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.get("/kusto/schema", response_model=DatabaseSchema, dependencies=guarded)
async def kusto_schema(cluster: str, database: str) -> DatabaseSchema:
    try:
        return await kusto.database_schema(cluster, database)
    except kusto.KustoError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.post("/kusto/knowledge/generate", dependencies=[*guarded, Depends(require_local_action)])
async def generate_knowledge(request: knowledge.SchemaRequest):
    try:
        return await knowledge.generate(request)
    except kusto.KustoError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error


@app.get("/repo/search", dependencies=guarded)
async def repo_search(response: Response, q: str = "") -> list[dict[str, Any]]:
    response.headers.update(DEMO_HEADER)
    return search.search_repositories(q)


@app.get("/enghub/search", response_model=GuideResults, dependencies=guarded)
async def enghub_search(
    response: Response, q: str = Query(default="", max_length=2000),
    skip: int = Query(default=0, ge=0, le=100_000), top: int = Query(default=10, ge=1, le=50),
) -> GuideResults:
    try:
        result = await enghub.search_guides(q, skip, top, launcher_config.load_config().preferences)
    except enghub.EngHubError as error:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, str(error)) from error
    response.headers["X-Atlas-Source"] = "Live"
    return GuideResults(**result)


@app.get("/enghub/page", dependencies=guarded)
async def enghub_page(response: Response, route: str = Query(min_length=1, max_length=4096)):
    try:
        result = await enghub.get_page(route)
    except ValueError as error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(error)) from error
    except enghub.EngHubError as error:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, str(error)) from error
    response.headers["X-Atlas-Source"] = "Live"
    return result


@app.get("/catalogue", dependencies=guarded)
async def catalogue(response: Response) -> dict[str, list[dict[str, Any]]]:
    """The whole index in one call.

    The launcher needs it to resolve pinned items and shared links back to real records, which
    a search endpoint cannot do.
    """
    response.headers.update(DEMO_HEADER)
    return {
        "repositories": search.repositories(),
        "guides": [],
        "tools": search.tools(),
    }


@app.get("/tools", dependencies=guarded)
async def tools(response: Response, q: str = "") -> list[dict[str, Any]]:
    response.headers.update(DEMO_HEADER)
    return search.search_tools(q)
