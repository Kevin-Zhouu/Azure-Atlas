"""Entry point: ``python -m atlas_backend``.

The launcher starts the service this way, and an engineer can start it by hand with the same
command when developing against the browser preview.
"""

from __future__ import annotations

import logging
import os
import sys
import threading

import uvicorn

from .config import settings

log = logging.getLogger("atlas")


def _exit_with_parent() -> None:
    """Ends the process when the launcher that started it goes away.

    The launcher holds the write end of this process's stdin. Closing it — whether Atlas exits
    cleanly or is killed outright — produces EOF here, which is the only signal that survives a
    hard kill. Without it a crashed launcher would leave the service listening on loopback.
    """

    def watch() -> None:
        try:
            sys.stdin.buffer.read()
        except Exception:  # noqa: BLE001 - any read failure means the pipe is gone
            pass
        log.info("Launcher closed the supervision pipe; stopping.")
        # Uvicorn owns the event loop from another thread, so exit rather than unwind through it.
        os._exit(0)

    threading.Thread(target=watch, name="parent-watchdog", daemon=True).start()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    if os.environ.get("ATLAS_SUPERVISED") == "1":
        _exit_with_parent()
    uvicorn.run(
        "atlas_backend.app:app",
        host=settings.host,
        port=settings.port,
        log_level="info",
        access_log=False,
    )


if __name__ == "__main__":
    main()
