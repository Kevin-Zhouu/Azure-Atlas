"""Local command configuration. No credentials or execution approvals are persisted."""

from __future__ import annotations

import json
import os
import re
import tempfile
import threading
from pathlib import Path
from typing import Literal
from urllib.parse import unquote, urlsplit

from pydantic import BaseModel, ConfigDict, Field, ValidationError

RESERVED = {"repo", "ado", "copilot", "icm", "code", "enghub", "kusto", "kql", "kusto-run", "open",
            "home", "recent", "pinned", "settings", "agent"}
NAME = re.compile(r"^[a-z][a-z0-9-]*$")
PLACEHOLDER = re.compile(r"\{([a-z][a-z0-9-]*)\}")
_lock = threading.RLock()


class ConfigError(ValueError):
    pass


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Repository(Model):
    name: str = Field(min_length=1, max_length=120)
    alias: str = Field(min_length=1, max_length=60)
    path: str = Field(min_length=1, max_length=4096)
    adoUrl: str = Field(min_length=1, max_length=4096)


class Shortcut(Model):
    command: str = Field(min_length=1, max_length=60)
    description: str = Field(default="", max_length=240)
    arguments: list[str] = Field(default_factory=list, max_length=20)
    flags: list[str] = Field(default_factory=list, max_length=20)
    action: Literal["url", "path", "application", "shell"]
    template: str = Field(min_length=1, max_length=8000)


class Cluster(Model):
    name: str = Field(min_length=1, max_length=120)
    url: str
    database: str = Field(min_length=1, max_length=200)


class KnowledgeItem(Model):
    id: str
    name: str
    type: Literal["Schema", "Instructions", "Cookbook", "Runbook"]
    cluster: str = ""
    database: str = ""
    content: str = Field(max_length=500_000)
    source: str = ""
    updated: str = ""
    generated: bool = False
    docstrings: bool = True
    samples: bool = False
    functions: bool = True


class Agent(Model):
    """One entry in ``/agent``. ``copilot`` agents are written out as a Copilot CLI custom
    agent file and started with ``--agent``; ``command`` agents run a PowerShell line the
    engineer supplied, with ``{arg}`` replaced by whatever they typed after the name."""

    id: str = Field(min_length=1, max_length=120)
    name: str = Field(min_length=1, max_length=60)
    description: str = Field(default="", max_length=400)
    instructions: str = Field(default="", max_length=200_000)
    mode: Literal["copilot", "command"] = "copilot"
    command: str = Field(default="", max_length=8000)
    repo: str = Field(default="", max_length=60)
    model: str = Field(default="", max_length=120)
    source: str = Field(default="", max_length=400)
    updated: str = ""


class CatalogueShortcut(Model):
    id: str
    name: str
    description: str = ""
    url: str
    category: str = "Shortcuts"
    pinned: bool = False


class Preferences(Model):
    hotkey: str = "Ctrl+Shift+Space"
    launchAtSignIn: bool = False
    showRecent: bool = True
    model: str = Field(default="", max_length=120)
    #: How much the model deliberates before answering. Reasoning models spend real seconds
    #: here: on a typical production database "fast" returns a correct query in about 4.3s
    #: where "balanced" takes 7.0s. Query generation is a short, well-grounded task, so fast
    #: is the default and the slower settings are there for prompts that need the thought.
    reasoning: Literal["fast", "balanced", "thorough"] = "fast"
    clusters: list[Cluster] = Field(default_factory=list, max_length=100)
    defaultCluster: str = ""
    knowledge: list[KnowledgeItem] = Field(default_factory=list, max_length=200)
    modelNotes: str = Field(default="", max_length=20000)
    #: Off by default. Generating on every typing pause asks the model a question the
    #: engineer is still in the middle of writing, and even with superseded questions
    #: abandoned it leaves them waiting longer than pressing Enter once does.
    generateAsYouType: bool = False
    runAutomatically: bool = False
    useKnowledge: bool = True
    schemaRefresh: Literal["weekly", "every3days", "daily", "manually"] = "weekly"
    rowLimit: int = Field(default=2000, ge=1, le=10000)
    teamSpaceUrl: str = ""
    teamTsgUrl: str = ""
    preferTeam: bool = True
    includeRelated: bool = True
    staleness: int = Field(default=0, ge=0, le=3650)
    priorityRepos: list[str] = Field(default_factory=list)
    pageSize: int = Field(default=5, ge=1, le=50)
    codeOpenIn: Literal["ado", "vscode"] = "ado"
    catalogue: list[CatalogueShortcut] = Field(default_factory=list, max_length=500)
    removedTools: list[str] = Field(default_factory=list)
    agents: list[Agent] = Field(default_factory=list, max_length=100)


class LauncherConfig(Model):
    repositories: list[Repository] = Field(default_factory=list, max_length=100)
    shortcuts: list[Shortcut] = Field(default_factory=list, max_length=100)
    adoOrganizations: list[str] = Field(default_factory=list, max_length=10)
    icmQueriesUrl: str = ""
    preferences: Preferences = Field(default_factory=Preferences)


def config_path() -> Path:
    override = os.environ.get("ATLAS_CONFIG_FILE")
    if override:
        return Path(override)
    return Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".config"))) / "AzureAtlas" / "commands.json"


def https_url(raw: str) -> str:
    try:
        parsed = urlsplit(raw)
        if (parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password
                or parsed.port not in (None, 443) or "\\" in raw or any(c.isspace() or ord(c) < 32 for c in raw)):
            raise ValueError()
    except ValueError as error:
        raise ConfigError("Use an HTTPS URL without credentials, whitespace, or a custom port.") from error
    return raw


def ado_organization(raw: str, repository: bool = False) -> str:
    parsed = urlsplit(https_url(raw))
    parts = [unquote(part) for part in parsed.path.split("/") if part]
    host = parsed.hostname or ""
    if host == "dev.azure.com" and parts:
        organization, rest = parts[0], parts[1:]
    elif host.endswith(".visualstudio.com"):
        organization, rest = host.removesuffix(".visualstudio.com"), parts
        if rest and rest[0].lower() == "defaultcollection":
            rest = rest[1:]
    else:
        raise ConfigError("Use an Azure DevOps URL: https://dev.azure.com/organization/project/_git/repository.")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9-]*", organization):
        raise ConfigError("Invalid Azure DevOps organization.")
    if repository and (len(rest) != 3 or rest[1] != "_git" or not rest[0] or not rest[2]):
        raise ConfigError("Use the repository URL, including project/_git/repository.")
    return organization.lower()


def local_path(raw: str, *, directory: bool = False) -> Path:
    path = Path(raw)
    if not path.is_absolute() or raw.startswith(("\\\\", "//")):
        raise ConfigError("Use an absolute local path, not a relative path or network share.")
    if not path.exists() or (directory and not path.is_dir()):
        raise ConfigError(f"Local {'directory' if directory else 'path'} does not exist: {raw}")
    return path


def validate_shortcut(shortcut: Shortcut) -> Shortcut:
    shortcut = shortcut.model_copy(update={"command": shortcut.command.removeprefix("/").lower()})
    if not NAME.fullmatch(shortcut.command) or shortcut.command in RESERVED:
        raise ConfigError("Choose a non-reserved command using letters, digits and hyphens.")
    names = shortcut.arguments + shortcut.flags
    if any(not NAME.fullmatch(name) for name in names) or len(names) != len(set(names)):
        raise ConfigError("Argument and flag names must be unique lowercase names, for example topic.")
    unknown = set(PLACEHOLDER.findall(shortcut.template)) - set(names)
    if unknown:
        raise ConfigError(f"Declare template arguments first: {', '.join(sorted(unknown))}.")
    if "\x00" in shortcut.template:
        raise ConfigError("Action templates cannot contain null characters.")
    return shortcut


def validate_config(config: LauncherConfig, *, check_paths: bool) -> LauncherConfig:
    keys: set[str] = set()
    for repo in config.repositories:
        repo.alias = repo.alias.lower()
        if not NAME.fullmatch(repo.alias):
            raise ConfigError("Repository aliases must start with a letter and contain letters, digits or hyphens.")
        identifiers = {repo.name.casefold(), repo.alias.casefold()}
        if keys & identifiers:
            raise ConfigError(f"Duplicate repository name or alias: {repo.alias}.")
        keys.update(identifiers)
        ado_organization(repo.adoUrl, repository=True)
        if check_paths:
            local_path(repo.path, directory=True)
    config.shortcuts = [validate_shortcut(shortcut) for shortcut in config.shortcuts]
    commands = [shortcut.command for shortcut in config.shortcuts]
    if len(set(commands)) != len(commands):
        raise ConfigError("Custom command names must be unique.")
    organizations = []
    for raw in config.adoOrganizations:
        organization = ado_organization(raw)
        if organization not in organizations:
            organizations.append(organization)
    config.adoOrganizations = [f"https://dev.azure.com/{org}" for org in organizations]
    if config.icmQueriesUrl:
        https_url(config.icmQueriesUrl)
        if urlsplit(config.icmQueriesUrl).hostname != "portal.microsofticm.com":
            raise ConfigError("Use an Incident Queries URL on portal.microsofticm.com.")
    preferences = config.preferences
    urls = set()
    for cluster in preferences.clusters:
        parsed = urlsplit(https_url(cluster.url))
        if (not re.fullmatch(r"[a-z0-9-]+(?:\.[a-z0-9-]+)*\.kusto\.windows\.net", parsed.hostname or "")
                or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
            raise ConfigError("Use a cluster URL such as https://help.kusto.windows.net.")
        cluster.url = cluster.url.rstrip("/")
        if cluster.url in urls:
            raise ConfigError("This cluster is already configured.")
        urls.add(cluster.url)
    if preferences.defaultCluster and preferences.defaultCluster not in urls:
        raise ConfigError("The default cluster must be a configured cluster.")
    for item in preferences.catalogue:
        parsed = urlsplit(item.url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password:
            raise ConfigError("Shortcut links must be HTTP or HTTPS URLs without credentials.")
    for url in (preferences.teamSpaceUrl, preferences.teamTsgUrl):
        if url:
            https_url(url)
    names: set[str] = set()
    for agent in preferences.agents:
        agent.name = agent.name.strip().removeprefix("/").lower()
        if not NAME.fullmatch(agent.name):
            raise ConfigError("Agent names must start with a letter and contain letters, digits or hyphens.")
        if agent.name in names:
            raise ConfigError(f"Duplicate agent name: {agent.name}.")
        names.add(agent.name)
        if agent.mode == "command" and not agent.command.strip():
            raise ConfigError(f"Agent {agent.name} runs a command, so a command line is required.")
        if agent.mode == "copilot" and not agent.instructions.strip():
            raise ConfigError(f"Agent {agent.name} needs instructions for Copilot CLI to follow.")
        if "\x00" in agent.command or "\x00" in agent.instructions:
            raise ConfigError("Agents cannot contain null characters.")
        if agent.repo and not any(repo.alias == agent.repo.lower() for repo in config.repositories):
            raise ConfigError(f"Agent {agent.name} refers to an unknown repository alias: {agent.repo}.")
    return config


def load_config() -> LauncherConfig:
    with _lock:
        path = config_path()
        if not path.exists():
            return LauncherConfig()
        try:
            return validate_config(LauncherConfig.model_validate_json(path.read_text(encoding="utf-8")), check_paths=False)
        except (OSError, ValidationError, ValueError) as error:
            raise ConfigError(f"Cannot read command configuration at {path}: {error}") from error


def save_config(config: LauncherConfig) -> LauncherConfig:
    with _lock:
        config = validate_config(config.model_copy(deep=True), check_paths=True)
        path = config_path()
        temporary = None
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as file:
                temporary = Path(file.name)
                json.dump(config.model_dump(), file, indent=2)
                file.flush()
                os.fsync(file.fileno())
            os.replace(temporary, path)
        except OSError as error:
            raise ConfigError(f"Cannot save command configuration: {error}") from error
        finally:
            if temporary and temporary.exists():
                temporary.unlink()
        sync_agent_files(config)
        return config


def agents_dir() -> Path:
    """Where Atlas keeps the Copilot CLI custom agent files it generates.

    The layout matters: ``copilot --add-dir <dir>`` loads trusted configuration from
    ``<dir>/.github/agents``, so the directory handed to the CLI is the parent of that pair.
    """
    return config_path().parent / "agents"


def _agent_file(agent: Agent) -> str:
    """A Copilot CLI custom agent file: YAML front matter, then the instructions."""
    description = agent.description.replace("\n", " ").replace('"', "'").strip()
    return (
        "---\n"
        f"name: {agent.name}\n"
        f'description: "{description or f"Azure Atlas agent {agent.name}"}"\n'
        "---\n\n"
        f"{agent.instructions.strip()}\n"
    )


def sync_agent_files(config: LauncherConfig) -> Path:
    """Writes one file per Copilot agent and deletes the ones Atlas no longer knows about.

    Only files Atlas itself wrote are removed: anything without the generated marker is left
    alone, so an engineer can drop a hand-written agent in the same folder.
    """
    directory = agents_dir() / ".github" / "agents"
    wanted = {f"{agent.name}.md": agent for agent in config.preferences.agents if agent.mode == "copilot"}
    try:
        directory.mkdir(parents=True, exist_ok=True)
        for existing in directory.glob("*.md"):
            if existing.name not in wanted:
                existing.unlink(missing_ok=True)
        for filename, agent in wanted.items():
            target = directory / filename
            content = _agent_file(agent)
            if not target.exists() or target.read_text(encoding="utf-8") != content:
                target.write_text(content, encoding="utf-8")
    except OSError as error:
        raise ConfigError(f"Cannot write agent files to {directory}: {error}") from error
    return agents_dir()


def resolve_repository(config: LauncherConfig, identifier: str) -> Repository:
    identifier = identifier.strip().strip('"').casefold()
    for repo in config.repositories:
        if identifier in (repo.alias.casefold(), repo.name.casefold()):
            return repo
    suggestions = ", ".join(f"{repo.alias} ({repo.name})" for repo in config.repositories)
    raise ConfigError(
        (f"Unknown repository: {identifier}. " if identifier else "A repository name or alias is required. ")
        + (f"Available repositories: {suggestions}." if suggestions else "Add a repository in Settings > Repositories.")
    )


def replace_generated_knowledge(previous: KnowledgeItem, replacement: KnowledgeItem) -> None:
    with _lock:
        config = load_config()
        for index, item in enumerate(config.preferences.knowledge):
            if item.id == previous.id and item.model_dump() == previous.model_dump():
                config.preferences.knowledge[index] = replacement.model_copy(update={"id": item.id, "name": item.name})
                save_config(config)
                return
