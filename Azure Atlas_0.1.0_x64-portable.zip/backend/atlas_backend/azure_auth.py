"""Shared Azure CLI identity and resource-token acquisition.

Tokens stay in the backend process and are never returned by an HTTP endpoint.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import time

from .config import settings
from .models import AuthStatus
from . import accounts, credentials

TOKEN_TTL_SECONDS = 25 * 60
_CREATE_NO_WINDOW = 0x0800_0000
_tokens: dict[str, tuple[str, float]] = {}
_locks: dict[asyncio.AbstractEventLoop, asyncio.Lock] = {}


class AzureAuthError(Exception):
    pass


def _first_lines(text: str, count: int) -> str:
    return " ".join([line for line in text.splitlines() if line.strip()][:count])


def run_az(args: list[str]) -> str:
    """Run Azure CLI without inheriting the launcher's supervision pipe."""
    if sys.platform == "win32":
        comspec = os.environ.get("COMSPEC", "cmd.exe")
        command: list[str] = [
            comspec,
            "/d",
            "/s",
            "/c",
            subprocess.list2cmdline(["az", *args]),
        ]
        flags = _CREATE_NO_WINDOW
    else:
        command = ["az", *args]
        flags = 0
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            stdin=subprocess.DEVNULL,
            text=True,
            creationflags=flags,
            timeout=120,
        )
    except FileNotFoundError as error:
        raise AzureAuthError(
            f"The Azure CLI could not be started ({error}). Install it, then run az login."
        ) from error
    except subprocess.TimeoutExpired as error:
        raise AzureAuthError(
            "The Azure CLI did not respond. Try running az login manually."
        ) from error

    if completed.returncode == 0:
        return (completed.stdout or "").strip()

    detail = (completed.stderr or "").strip()
    if "not recognized" in detail or "not found" in detail:
        raise AzureAuthError("The Azure CLI is not on PATH. Install it, then run az login.")
    if "az login" in detail or "AADSTS" in detail or "Please run" in detail:
        raise AzureAuthError("Azure CLI sign-in is required. Run az login, then try again.")
    raise AzureAuthError(
        f"Azure CLI: {_first_lines(detail, 3)}"
        if detail
        else "The Azure CLI reported an error."
    )


def _lock() -> asyncio.Lock:
    loop = asyncio.get_running_loop()
    return _locks.setdefault(loop, asyncio.Lock())


async def access_token(resource: str) -> str:
    """Return a token scoped to one Azure resource, cached only in memory."""
    async with _lock():
        cached = _tokens.get(resource)
        if cached and (time.monotonic() - cached[1]) < TOKEN_TTL_SECONDS:
            return cached[0]
        try:
            managed = await accounts.azure_token(resource)
        except (accounts.AccountError, credentials.CredentialError) as error:
            raise AzureAuthError(str(error)) from error
        if managed:
            _tokens[resource] = (managed, time.monotonic())
            return managed
        raw = await asyncio.to_thread(
            run_az,
            ["account", "get-access-token", "--resource", resource, "--output", "json"],
        )
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError as error:
            raise AzureAuthError("The Azure CLI returned an unreadable token response.") from error
        token = parsed.get("accessToken")
        if not isinstance(token, str) or not token:
            raise AzureAuthError(
                "The Azure CLI did not return an access token. Run az login and try again."
            )
        _tokens[resource] = (token, time.monotonic())
        return token


async def auth_status() -> AuthStatus:
    """Report the current Azure CLI identity without acquiring or exposing a token."""
    if settings.demo_mode:
        return AuthStatus(
            available=True,
            signed_in=False,
            message="Demonstration mode. Sign in with the Azure CLI to run live queries.",
        )
    try:
        saved = credentials.read("azure")
    except credentials.CredentialError as error:
        return AuthStatus(available=False, signed_in=False, message=str(error))
    if saved is not None:
        signed_in = bool(saved.get("refresh_token")) and not saved.get("disabled", False)
        return AuthStatus(available=True, signed_in=signed_in, account=saved.get("account"), tenant=saved.get("tenant"),
                          message=accounts.status_error("azure") or ("Signed in through Azure Atlas" if signed_in else "Sign in to Azure DevOps."))
    if accounts.status_error("azure"):
        return AuthStatus(available=True, signed_in=False, message=accounts.status_error("azure"))
    try:
        raw = await asyncio.to_thread(run_az, ["account", "show", "--output", "json"])
    except AzureAuthError as error:
        message = str(error)
        reachable = "not on PATH" not in message and "could not be started" not in message
        return AuthStatus(available=reachable, signed_in=False, message=message)
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        parsed = {}
    account = (parsed.get("user") or {}).get("name")
    return AuthStatus(
        available=True,
        signed_in=True,
        account=account,
        tenant=parsed.get("tenantId"),
        message=f"Signed in as {account}" if account else "Signed in with the Azure CLI",
    )