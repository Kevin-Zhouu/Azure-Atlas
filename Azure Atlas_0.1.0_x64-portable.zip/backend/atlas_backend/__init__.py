"""Local engineering service behind the Azure Atlas launcher."""

__version__ = "0.1.0"
