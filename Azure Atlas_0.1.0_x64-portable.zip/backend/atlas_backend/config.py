"""Runtime settings, all supplied by the launcher through the environment."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

DEFAULT_PORT = 8787
# The Tauri webview serves from these origins; the Vite dev server uses 1420.
DEFAULT_ORIGINS = (
    "http://localhost:1420",
    "http://127.0.0.1:1420",
    "tauri://localhost",
    "http://tauri.localhost",
    "https://tauri.localhost",
)


def _int(name: str, fallback: int) -> int:
    try:
        return int(os.environ[name])
    except (KeyError, ValueError):
        return fallback


def _float(name: str, fallback: float) -> float:
    try:
        return float(os.environ[name])
    except (KeyError, ValueError):
        return fallback


def _bool(name: str, fallback: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return fallback
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    """Everything the service needs to start.

    The service binds to the loopback interface only. It is a local helper for one
    signed-in engineer, never a shared server.
    """

    host: str = field(default_factory=lambda: os.environ.get("ATLAS_HOST", "127.0.0.1"))
    port: int = field(default_factory=lambda: _int("ATLAS_PORT", DEFAULT_PORT))
    #: Shared secret issued by the launcher. When unset the service runs open for local
    #: development, and says so in ``/health`` rather than pretending to be protected.
    token: str | None = field(default_factory=lambda: os.environ.get("ATLAS_TOKEN") or None)
    origins: tuple[str, ...] = DEFAULT_ORIGINS
    demo_cluster: str = field(
        default_factory=lambda: os.environ.get(
            "ATLAS_DEMO_CLUSTER", "https://help.kusto.windows.net"
        )
    )
    demo_database: str = field(
        default_factory=lambda: os.environ.get("ATLAS_DEMO_DATABASE", "Samples")
    )
    #: The cluster and database the launcher opens on. Prewarming these means the first
    #: generation of a session is as fast as the ones after it. Out of the box this is the
    #: public Kusto help cluster; engineers point it at their own under Preferences → Kusto.
    default_cluster: str = field(
        default_factory=lambda: os.environ.get(
            "ATLAS_DEFAULT_CLUSTER", "https://help.kusto.windows.net"
        )
    )
    default_database: str = field(
        default_factory=lambda: os.environ.get("ATLAS_DEFAULT_DATABASE", "Samples")
    )
    #: Which Copilot model generates KQL. Claude Opus 5 answers a warm session in about

    #: three seconds; override when a plan does not include it, or to trade quality for speed.
    copilot_model: str = field(
        default_factory=lambda: os.environ.get("ATLAS_COPILOT_MODEL", "claude-opus-5")
    )
    #: Seconds to wait for one generation before giving the engineer an error they can act on.
    copilot_timeout: float = field(
        default_factory=lambda: _float("ATLAS_COPILOT_TIMEOUT", 45.0)
    )
    #: How long a fetched database schema stays usable. Schemas change rarely, and refetching
    #: costs a round trip that would otherwise sit inside every generation.
    schema_ttl: float = field(default_factory=lambda: _float("ATLAS_SCHEMA_TTL", 900.0))
    #: Report every integration as signed out so the launcher shows its demonstration path.
    #: The end-to-end suite sets this; without it the suite would pass or fail depending on
    #: whether the machine running it happens to hold Azure credentials.
    demo_mode: bool = field(default_factory=lambda: _bool("ATLAS_DEMO_MODE"))

    @property
    def auth_required(self) -> bool:
        return self.token is not None

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}"


settings = Settings()
