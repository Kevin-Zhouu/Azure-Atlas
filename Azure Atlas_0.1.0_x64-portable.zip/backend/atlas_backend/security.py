"""Bearer-token guard for every route except the readiness probe."""

from __future__ import annotations

import secrets

from fastapi import Header, HTTPException, Request, status

from .config import settings

_UNAUTHORISED = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="A valid Atlas backend token is required.",
    headers={"WWW-Authenticate": "Bearer"},
)


async def require_token(authorization: str | None = Header(default=None)) -> None:
    """Reject callers that cannot present the launcher's token.

    Any process on the machine can reach a loopback port, so the token is what stops an
    unrelated local program from running Kusto queries with the engineer's credentials.
    """
    if not settings.auth_required:
        return
    scheme, _, presented = (authorization or "").partition(" ")
    if scheme.lower() != "bearer" or not presented:
        raise _UNAUTHORISED
    # Constant-time comparison keeps the check free of timing signal.
    if not secrets.compare_digest(presented, settings.token or ""):
        raise _UNAUTHORISED


async def require_local_action(request: Request) -> None:
    """CORS alone does not block side effects from a hostile browser origin."""
    origin = request.headers.get("origin")
    if origin and origin not in settings.origins:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Local actions require an Atlas origin.")
    if request.headers.get("sec-fetch-site") == "cross-site" and not origin:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Cross-site local actions are disabled.")
    if request.headers.get("content-type", "").split(";")[0].strip() != "application/json":
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "Local actions require application/json.")
