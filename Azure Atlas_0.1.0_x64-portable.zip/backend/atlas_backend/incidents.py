"""The focused incident scenario used by the Atlas MVP demo."""

from __future__ import annotations

from .config import settings
from .models import (
    IncidentCodeReference,
    IncidentDocument,
    IncidentSummary,
    QueryRequest,
)

DEMO_INCIDENT_ID = "1234567890"


def get_incident(incident_id: str) -> IncidentSummary | None:
    if incident_id != DEMO_INCIDENT_ID:
        return None

    return IncidentSummary(
        incident_id=incident_id,
        title="PCS hardware processing failures after the latest production deployment",
        status="Active",
        severity="2",
        summary=(
            "Exception volume increased immediately after deployment prod-2026.09.14.1. "
            "Failures are concentrated in the PCS hardware processing workflow."
        ),
        workflow_name="ProcessPcsHardware",
        owner_team="Azure Compute Hardware Lifecycle",
        icm_url=f"https://portal.microsofticm.com/imp/v5/incidents/details/{incident_id}/home",
        code=IncidentCodeReference(
            repository="Azure.Compute.Hardware",
            file="ProcessPcsHardware.cs",
            path="src/Workflows/ProcessPcsHardware.cs",
            line=87,
            symbol="ProcessPcsHardware",
            reason="The incident workflow name exactly matches this handler.",
        ),
        documents=[
            IncidentDocument(
                title="PCS hardware processing failures",
                url="demo://enghub/compute/pcs-hardware-processing",
                reason="Primary troubleshooting guide for this workflow.",
            ),
            IncidentDocument(
                title="Validate a deployment-related exception spike",
                url="demo://enghub/deployments/exception-spike",
                reason="Matches the post-deployment timing in the incident.",
            ),
        ],
        suggested_query=QueryRequest(
            cluster=settings.demo_cluster,
            database=settings.demo_database,
            query=(
                "ServiceExceptions\n"
                "| where Timestamp >= ago(3d)\n"
                "| where DeploymentId == 'prod-2026.09.14.1'\n"
                "| where WorkflowName == 'ProcessPcsHardware'\n"
                "| summarize ExceptionCount = count() by bin(Timestamp, 15m)\n"
                "| order by Timestamp asc\n"
                "| render timechart"
            ),
            mode="live",
        ),
    )