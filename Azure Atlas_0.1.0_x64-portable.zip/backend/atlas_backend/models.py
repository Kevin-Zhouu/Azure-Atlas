"""Wire contracts shared with the launcher.

Field names are camelCase on the wire so the TypeScript types in ``src/types.ts`` stay the
single description of the shape, and no translation layer is needed in the client.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

ProviderState = Literal["Demo", "Live", "Unavailable"]
Scenario = Literal["success", "empty", "error"]


class Wire(BaseModel):
    """Serialises as camelCase while accepting either casing on input."""

    model_config = ConfigDict(populate_by_name=True, alias_generator=None)


class Column(Wire):
    name: str
    type: str


class Visualization(Wire):
    """The ``render`` directive a query asked for, as reported by the cluster.

    Kusto returns these fields mostly unset, leaving the client to infer axes from column
    types the same way Azure Data Explorer does. Only ``kind`` is always present.
    """

    kind: str
    title: str | None = None
    x_column: str | None = Field(default=None, serialization_alias="xColumn")
    series: list[str] = Field(default_factory=list)
    y_columns: list[str] = Field(default_factory=list, serialization_alias="yColumns")
    x_title: str | None = Field(default=None, serialization_alias="xTitle")
    y_title: str | None = Field(default=None, serialization_alias="yTitle")
    accumulate: bool = False


class QueryResult(Wire):
    columns: list[Column]
    rows: list[list[Any]]
    duration_ms: int = Field(serialization_alias="durationMs")
    source: ProviderState
    truncated: bool = False
    total_rows: int = Field(default=0, serialization_alias="totalRows")
    visualization: Visualization | None = None
    statistics: dict[str, str] = Field(default_factory=dict)


class QueryRequest(Wire):
    cluster: str
    database: str
    query: str
    mode: Literal["live", "demo"] = "demo"
    scenario: Scenario = "success"


class KustoGenerationRequest(Wire):
    prompt: str = Field(min_length=1, max_length=2000)
    cluster: str
    database: str
    current_query: str = Field(default="", max_length=100_000, alias="currentQuery")


class GeneratedQuery(Wire):
    title: str
    explanation: str
    request: QueryRequest


class SchemaColumn(Wire):
    name: str
    type: str


class TableSchema(Wire):
    name: str
    columns: list[SchemaColumn]


class DatabaseSchema(Wire):
    cluster: str
    database: str
    tables: list[TableSchema]


class IncidentCodeReference(Wire):
    repository: str
    file: str
    path: str
    line: int
    symbol: str
    reason: str


class IncidentDocument(Wire):
    title: str
    url: str
    reason: str


class IncidentSummary(Wire):
    incident_id: str = Field(serialization_alias="incidentId")
    title: str
    status: str
    severity: str
    summary: str
    workflow_name: str = Field(serialization_alias="workflowName")
    owner_team: str = Field(serialization_alias="ownerTeam")
    icm_url: str = Field(serialization_alias="icmUrl")
    code: IncidentCodeReference
    documents: list[IncidentDocument]
    suggested_query: QueryRequest = Field(serialization_alias="suggestedQuery")


class CodeCaller(Wire):
    file: str
    path: str
    line: int
    snippet: str


class CodeSearchResult(Wire):
    repository: str
    file: str
    path: str
    line: int
    symbol: str
    language: str
    snippet: str
    callers: list[CodeCaller]
    documents: list[IncidentDocument]
    source: ProviderState


class AuthStatus(Wire):
    available: bool
    signed_in: bool = Field(serialization_alias="signedIn")
    account: str | None = None
    tenant: str | None = None
    message: str


class CopilotStatus(Wire):
    """Whether Copilot can generate a query right now, and as whom."""

    available: bool
    signed_in: bool = Field(serialization_alias="signedIn")
    account: str | None = None
    method: str | None = None
    model: str
    message: str


class DeviceLogin(Wire):
    """The two things an engineer needs to finish a GitHub device sign-in."""

    verification_uri: str = Field(serialization_alias="verificationUri")
    user_code: str = Field(serialization_alias="userCode")


class PrewarmRequest(Wire):
    cluster: str
    database: str


class Health(Wire):
    status: Literal["ok"] = "ok"
    version: str
    kusto: ProviderState
    repositories: ProviderState = "Demo"
    guides: ProviderState = "Demo"
    tools: ProviderState = "Demo"
    auth_required: bool = Field(serialization_alias="authRequired")


class GuideResults(Wire):
    strong: list[dict[str, Any]]
    related: list[dict[str, Any]]
    total: int = 0
    source: ProviderState = "Live"
