"""Editable, scoped Kusto knowledge. Only fixed read-only schema commands are issued."""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import datetime, timezone, timedelta

from pydantic import Field

from . import kusto, launcher_config

logger = logging.getLogger("atlas.knowledge")


class SchemaRequest(launcher_config.Model):
    cluster: str
    database: str = Field(min_length=1, max_length=200)
    docstrings: bool = True
    samples: bool = False
    functions: bool = True


async def generate(request: SchemaRequest) -> launcher_config.KnowledgeItem:
    cluster = kusto.normalise_cluster(request.cluster)
    _, rows, _ = await kusto.execute(cluster, request.database, ".show database schema as json", "/v1/rest/mgmt")
    raw = next((cell for row in rows for cell in row if isinstance(cell, str)), None)
    try:
        body = json.loads(raw or "")
        databases = body.get("Databases") or body.get("databases") or {}
        database = databases.get(request.database)
        if not isinstance(database, dict):
            raise ValueError()
        tables = database.get("Tables") or database.get("tables") or {}
        if not isinstance(tables, dict):
            raise ValueError()
    except (ValueError, AttributeError) as error:
        raise kusto.KustoError("The database schema response could not be parsed.") from error
    lines = [f"# {request.database}", f"Cluster: {cluster}", ""]
    for name, table in sorted(tables.items()):
        columns = table.get("OrderedColumns") or table.get("orderedColumns") or []
        lines.extend([f"## {name}", "```kusto", f"{name}(" + ", ".join(f"{column.get('Name')}:{column.get('CslType') or column.get('Type') or 'string'}" for column in columns) + ")", "```"])
        if request.docstrings:
            if table.get("DocString"):
                lines.append(str(table["DocString"]))
            lines.extend(f"- {column.get('Name')}: {column['DocString']}" for column in columns if column.get("DocString"))
        if request.samples:
            # KQL bracketed identifiers keep table names data rather than query syntax.
            identifier = name.replace("\\", "\\\\").replace("'", "\\'")
            sample_columns, sample_rows, _ = await kusto.execute(cluster, request.database, f"['{identifier}'] | take 1", "/v1/rest/query")
            lines.extend(["Sample values:", "```json", json.dumps([dict(zip([c.name for c in sample_columns], row)) for row in sample_rows], ensure_ascii=False, default=str), "```"])
    if request.functions:
        columns, rows, _ = await kusto.execute(cluster, request.database, ".show functions", "/v1/rest/mgmt")
        lines.extend(["## Functions", "```json", json.dumps([dict(zip([c.name for c in columns], row)) for row in rows], ensure_ascii=False, default=str), "```"])
    content = "\n".join(lines)
    if len(content) > 500_000:
        raise kusto.KustoError("The generated schema exceeds 500 KB. Turn off sample values or functions.")
    return launcher_config.KnowledgeItem(
        id=str(uuid.uuid4()), name=f"{request.database} schema", type="Schema",
        cluster=cluster, database=request.database, content=content, source=f"Generated from {cluster}",
        updated=datetime.now(timezone.utc).isoformat(), generated=True,
        docstrings=request.docstrings, samples=request.samples, functions=request.functions,
    )


async def refresh_due() -> None:
    config = launcher_config.load_config()
    days = {"weekly": 7, "every3days": 3, "daily": 1}.get(config.preferences.schemaRefresh)
    if days is None:
        return
    for item in config.preferences.knowledge:
        if not item.generated or not item.cluster or not item.database:
            continue
        try:
            updated = datetime.fromisoformat(item.updated.replace("Z", "+00:00"))
            if updated.tzinfo is None:
                updated = updated.replace(tzinfo=timezone.utc)
        except ValueError:
            updated = datetime.min.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - updated < timedelta(days=days):
            continue
        try:
            refreshed = await generate(SchemaRequest(cluster=item.cluster, database=item.database, docstrings=item.docstrings, samples=item.samples, functions=item.functions))
            launcher_config.replace_generated_knowledge(item, refreshed)
        except (kusto.KustoError, launcher_config.ConfigError) as error:
            logger.warning("Schema refresh for %s failed: %s", item.database, error)


async def refresh_loop() -> None:
    while True:
        try:
            await refresh_due()
        except launcher_config.ConfigError as error:
            logger.warning("Cannot refresh schemas: %s", error)
        await asyncio.sleep(3600)
