"""GitHub Copilot as the language-model provider for query generation.

Atlas talks to Copilot through the official ``github-copilot-sdk`` package, which drives the
Copilot CLI runtime over JSON-RPC. Two properties of that runtime shape everything here:

* Starting the runtime costs several seconds, and starting it per request costs that every
  time. The client is therefore started once and kept warm for the life of the process.
* A session that has already answered once answers the next question in roughly half the
  time of a freshly created one. Sessions are reused and recycled on a turn budget rather
  than rebuilt per request.

Measured on a developer machine with ``claude-opus-5``: a reused warm session returns a
generated query in about three seconds, against about six for a new session each time.

Authentication is deliberately not reimplemented. The SDK already resolves whichever GitHub
credential the engineer has — a Copilot CLI login, a ``gh`` CLI login, or a token in the
environment. When none is present, :func:`begin_device_login` drives the CLI's own device
flow and hands the verification URL and user code back for the launcher to display.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
from dataclasses import dataclass
from typing import Any

from .config import settings
from . import credentials, launcher_config, accounts

logger = logging.getLogger("atlas.copilot")

#: How many questions a session answers before it is rebuilt. Reuse is what keeps generation
#: fast, but conversation history grows with every turn, so it cannot be unbounded.
MAX_SESSION_TURNS = 16

#: Matches the verification URL and user code the CLI prints during the device flow.
_URL_PATTERN = re.compile(r"https://\S*github\.com/login/device\S*")
_CODE_PATTERN = re.compile(r"\b([A-Z0-9]{4}-[A-Z0-9]{4})\b")

_FENCE_PATTERN = re.compile(r"^\s*```(?:json|kql|kusto)?\s*|\s*```\s*$", re.IGNORECASE)


class CopilotError(RuntimeError):
    """Raised when Copilot cannot produce a usable answer.

    The message is shown to the engineer, so it says what to do rather than what broke.
    """


class Superseded(RuntimeError):
    """Raised when a newer request replaced this one before it could be answered.

    Generation runs as the engineer types, so by the time a question reaches the model the
    engineer has often already asked a better one. This is not a failure; it is the older
    answer being abandoned, and the caller is expected to discard it quietly.
    """


@dataclass(frozen=True)
class CopilotAuth:
    """Whether Copilot is usable, and as whom."""

    available: bool
    signed_in: bool
    account: str | None
    method: str | None
    message: str


def _strip_fences(content: str) -> str:
    """Remove a Markdown code fence if the model added one despite being asked not to."""
    text = content.strip()
    if "```" not in text:
        return text
    # Some models answer with prose either side of a single fenced block; keep the block.
    blocks = re.findall(r"```(?:json|kql|kusto)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
    if blocks:
        return blocks[0].strip()
    return _FENCE_PATTERN.sub("", text).strip()


def parse_json_object(content: str) -> dict[str, Any]:
    """Read the single JSON object a generation prompt asked for.

    Tolerates a code fence and leading or trailing prose, because a model that is otherwise
    correct should not fail the request over presentation.
    """
    text = _strip_fences(content)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            pass
    raise CopilotError("Copilot did not return a structured answer. Try rephrasing the request.")


class _Runtime:
    """Owns the one Copilot client and its current session.

    Every public method takes ``_lock`` so that concurrent requests share a single warm
    session instead of racing to build several.
    """

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._client: Any | None = None
        self._session: Any | None = None
        self._session_prompt: str | None = None
        self._session_model: str | None = None
        self._session_effort: str | None = None
        self._turns = 0
        self._waiting = 0
        self._newest = 0
        self._turn_id = 0
        self._running: int | None = None
        self._aborted: set[int] = set()
        self._login: asyncio.subprocess.Process | None = None

    # -- runtime lifecycle -------------------------------------------------------------

    @staticmethod
    def _sdk():
        try:
            import copilot  # noqa: PLC0415 - imported lazily so the service starts without it
        except ImportError as error:  # pragma: no cover - exercised only without the package
            raise CopilotError(
                "The GitHub Copilot SDK is not installed. Run "
                "'pip install github-copilot-sdk' in the backend environment."
            ) from error
        return copilot

    async def _client_ready(self) -> Any:
        if self._client is not None:
            return self._client
        sdk = self._sdk()
        try:
            saved = credentials.read("copilot")
        except credentials.CredentialError as error:
            raise CopilotError(str(error)) from error
        if saved and saved.get("disabled"):
            raise CopilotError("Signed out of Azure Atlas. Sign in under Preferences → General.")
        client = sdk.CopilotClient(log_level="error", **({"github_token": saved["token"], "use_logged_in_user": False} if saved and saved.get("token") else {}))
        try:
            await client.start()
        except Exception as error:
            raise CopilotError(f"The Copilot runtime did not start: {error}") from error
        self._client = client
        logger.info("Copilot runtime started")
        return client

    async def _session_ready(self, system_prompt: str) -> Any:
        """Return a warm session, rebuilding it when it is stale or the prompt changed.

        The system prompt is fixed for the life of a session, so a different prompt — local
        grounding being added for a database, say — needs a new session. So is the
        reasoning effort, which is why changing it in Preferences starts a fresh session.
        """
        model = configured_model()
        effort = configured_reasoning_effort()
        if (
            self._session is not None
            and self._session_prompt == system_prompt
            and self._session_model == model
            and self._session_effort == effort
            and self._turns < MAX_SESSION_TURNS
        ):
            return self._session

        await self._discard_session()
        sdk = self._sdk()
        client = await self._client_ready()
        try:
            self._session = await client.create_session(
                model=model,
                # Reasoning models otherwise deliberate for several seconds before writing
                # anything. Generation is a short, schema-grounded task, so this is the
                # single biggest lever on how long the engineer waits.
                reasoning_effort=effort,
                # Atlas never shows the model's reasoning, and asking for a summary of it is
                # more tokens generated before the answer arrives.
                reasoning_summary="none",
                on_permission_request=sdk.PermissionHandler.approve_all,
                system_message={"mode": "replace", "content": system_prompt},
                # Atlas wants one answer, not an agent. Everything below removes work the
                # runtime would otherwise do before it starts generating.
                available_tools=[],
                skip_custom_instructions=True,
                enable_config_discovery=False,
                enable_session_store=False,
                enable_skills=False,
                skip_embedding_retrieval=True,
            )
        except Exception as error:
            raise CopilotError(self._explain(error)) from error
        self._session_prompt = system_prompt
        self._session_model = model
        self._session_effort = effort
        self._turns = 0
        return self._session

    async def _discard_session(self) -> None:
        session = self._session
        self._session = None
        self._session_prompt = None
        self._session_effort = None
        self._turns = 0
        if session is None:
            return
        try:
            await session.disconnect()
        except Exception:  # pragma: no cover - a dead session is already what we wanted
            logger.debug("Discarding a Copilot session failed", exc_info=True)

    @staticmethod
    def _explain(error: Exception) -> str:
        """Turn an SDK failure into something the engineer can act on."""
        detail = str(error)
        lowered = detail.lower()
        if "model_not_supported" in lowered or "unsupported" in lowered:
            return (
                f"'{settings.copilot_model}' is not available on your Copilot plan. "
                "Set ATLAS_COPILOT_MODEL to a model you can use."
            )
        if "auth" in lowered or "401" in lowered or "403" in lowered:
            return "Copilot rejected the credential. Sign in to GitHub and try again."
        if "quota" in lowered or "rate" in lowered or "429" in lowered:
            return "Copilot is rate limiting this account. Wait a moment and try again."
        return f"Copilot could not answer: {detail}"

    # -- generation --------------------------------------------------------------------

    async def _abort_running(self) -> None:
        """Stop the turn in flight, because its answer is already out of date.

        The session survives this. Discarding it instead would cost the next request the
        several seconds a fresh session takes, which is the very thing being avoided.
        """
        turn, session = self._running, self._session
        if turn is None or session is None:
            return
        self._aborted.add(turn)
        try:
            await session.abort()
        except Exception:  # pragma: no cover - a turn that cannot be stopped simply finishes
            logger.debug("Aborting a superseded Copilot turn failed", exc_info=True)

    async def complete(self, system_prompt: str, user_prompt: str, *, coalesce: bool = False) -> str:
        """Ask Copilot one question and return the reply text.

        ``coalesce`` marks a question that only the engineer's latest version of matters.
        Generation runs as they type, so three pauses in one sentence used to mean three
        questions answered one after another on the single session: measured, the engineer
        waited 12.8 seconds after their last keystroke for a query that takes 3.4. With
        coalescing, an earlier question still in flight is aborted and one still queueing is
        dropped, so they wait for their last question only.
        """
        ticket = 0
        if coalesce:
            self._newest += 1
            ticket = self._newest
            await self._abort_running()
        # Counted only while queueing, so prewarming can see that someone real is waiting.
        self._waiting += 1
        try:
            await self._lock.acquire()
        finally:
            self._waiting -= 1
        try:
            if coalesce and ticket != self._newest:
                raise Superseded
            session = await self._session_ready(system_prompt)
            # Checked again here: waiting for the lock and building a session both take time,
            # and a question the engineer has already replaced should not be asked at all.
            if coalesce and ticket != self._newest:
                raise Superseded
            turn = self._turn_id = self._turn_id + 1
            self._running = turn if coalesce else None
            try:
                response = await asyncio.wait_for(
                    session.send_and_wait(user_prompt), timeout=settings.copilot_timeout
                )
            except asyncio.TimeoutError as error:
                # A session that timed out may still be mid-turn; never reuse it.
                await self._discard_session()
                raise CopilotError(
                    f"Copilot did not answer within {settings.copilot_timeout:.0f}s. Try again."
                ) from error
            except Exception as error:
                if turn in self._aborted:
                    raise Superseded from None
                await self._discard_session()
                raise CopilotError(self._explain(error)) from error
            finally:
                self._running = None
                self._aborted.discard(turn)
            self._turns += 1
            if coalesce and ticket != self._newest:
                raise Superseded
        finally:
            self._lock.release()

        content = getattr(getattr(response, "data", None), "content", None)
        if not isinstance(content, str) or not content.strip():
            raise CopilotError("Copilot returned an empty answer. Try rephrasing the request.")
        return content

    async def prewarm(self, system_prompt: str) -> None:
        """Pay the start-up cost before the engineer asks for anything.

        Creating a session is not enough. A session's first turn is consistently two to
        three seconds slower than its later ones, so the priming turn below is what makes
        the engineer's first real request as fast as their second.

        Priming is skipped the moment a real request is waiting, and abandoned if one arrives
        once it has started. It runs on the same single session, so an engineer who summons
        Atlas and types straight away would otherwise queue behind a turn asked on their
        behalf — which turned their first generation from roughly 6 seconds into 13.
        """
        try:
            async with self._lock:
                session = await self._session_ready(system_prompt)
                if self._turns or self._waiting:
                    return
                turn = self._turn_id = self._turn_id + 1
                self._running = turn
                try:
                    await asyncio.wait_for(
                        session.send_and_wait(
                            'Reply with exactly {"title":"ok","explanation":"ok","query":"print 1"}'
                        ),
                        timeout=settings.copilot_timeout,
                    )
                finally:
                    self._running = None
                    self._aborted.discard(turn)
                self._turns += 1
        except CopilotError as error:
            logger.info("Copilot prewarm skipped: %s", error)
        except Exception:  # pragma: no cover - prewarming must never break start-up
            logger.debug("Copilot prewarm failed", exc_info=True)

    # -- authentication ----------------------------------------------------------------

    async def auth(self) -> CopilotAuth:
        """Report whether Copilot has a usable GitHub credential."""
        if settings.demo_mode:
            return CopilotAuth(
                True, False, None, None, "Demonstration mode. Sign in to generate live queries."
            )
        failure = accounts.status_error("copilot")
        if failure:
            return CopilotAuth(True, False, None, None, failure)
        try:
            client = await self._client_ready()
            status = await asyncio.wait_for(client.get_auth_status(), timeout=20)
        except CopilotError as error:
            return CopilotAuth(False, False, None, None, str(error))
        except Exception as error:
            return CopilotAuth(
                True, False, None, None, f"Copilot sign-in state is unknown: {error}"
            )

        signed_in = bool(getattr(status, "isAuthenticated", False))
        login = getattr(status, "login", None)
        method = getattr(status, "authType", None)
        if signed_in:
            via = {"gh-cli": "the GitHub CLI", "copilot-cli": "the Copilot CLI"}.get(
                method or "", method or "GitHub"
            )
            return CopilotAuth(True, True, login, method, f"Signed in as {login} via {via}.")
        return CopilotAuth(
            True, False, None, method, "Sign in to GitHub to generate queries with Copilot."
        )

    async def models(self) -> list[str]:
        if settings.demo_mode:
            return [configured_model()]
        try:
            client = await self._client_ready()
            models = await asyncio.wait_for(client.list_models(), timeout=30)
            return [model.id for model in models]
        except CopilotError:
            raise
        except Exception as error:
            raise CopilotError(f"Could not list Copilot models: {error}") from error

    def _cli_path(self) -> str:
        """Find a Copilot CLI to run the device flow with."""
        override = os.environ.get("COPILOT_CLI_PATH")
        if override and os.path.exists(override):
            return override
        found = shutil.which("copilot")
        if found:
            return found
        local = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~/.local/share")
        root = os.path.join(local, "github-copilot-sdk", "cli")
        if os.path.isdir(root):
            for version in sorted(os.listdir(root), reverse=True):
                candidate = os.path.join(root, version, "copilot.exe")
                if os.path.exists(candidate):
                    return candidate
        raise CopilotError(
            "The GitHub Copilot CLI was not found. Install it, or sign in with 'gh auth login'."
        )

    async def begin_device_login(self) -> dict[str, str]:
        """Start the GitHub device flow and return the URL and code to show the engineer.

        The CLI process is left running: it polls GitHub until the engineer finishes in the
        browser, then stores the token itself. The launcher polls :meth:`auth` meanwhile.
        """
        await self.cancel_device_login()
        cli = self._cli_path()
        process = await asyncio.create_subprocess_exec(
            cli,
            "login",
            "--device-code",
            # The launcher supervises this service over its stdin pipe. A child that
            # inherits that pipe blocks forever, so it is always closed explicitly.
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        self._login = process

        url: str | None = None
        code: str | None = None
        try:
            async with asyncio.timeout(45):
                while url is None or code is None:
                    raw = await process.stdout.readline()
                    if not raw:
                        break
                    line = raw.decode("utf-8", "replace")
                    if url is None:
                        found = _URL_PATTERN.search(line)
                        if found:
                            url = found.group(0)
                    if code is None:
                        found = _CODE_PATTERN.search(line)
                        if found:
                            code = found.group(1)
        except TimeoutError:
            pass

        if not code:
            await self.cancel_device_login()
            raise CopilotError(
                "The Copilot CLI did not start a device login. Run 'copilot login' in a "
                "terminal to sign in."
            )
        return {"verificationUri": url or "https://github.com/login/device", "userCode": code}

    async def cancel_device_login(self) -> None:
        process, self._login = self._login, None
        if process is None or process.returncode is not None:
            return
        try:
            process.terminate()
            await asyncio.wait_for(process.wait(), timeout=5)
        except Exception:  # pragma: no cover - best effort cleanup
            logger.debug("Cancelling the Copilot device login failed", exc_info=True)

    async def login_finished(self) -> bool:
        """True when a device login is running and has exited."""
        return self._login is not None and self._login.returncode is not None

    async def refresh(self) -> None:
        """Rebuild the runtime so a newly stored credential is picked up."""
        async with self._lock:
            await self._discard_session()
            client, self._client = self._client, None
            if client is not None:
                try:
                    await client.stop()
                except Exception:  # pragma: no cover
                    logger.debug("Stopping the Copilot runtime failed", exc_info=True)

    async def shutdown(self) -> None:
        await self.cancel_device_login()
        await self.refresh()


_runtime = _Runtime()


def configured_model() -> str:
    return launcher_config.load_config().preferences.model or settings.copilot_model


#: How the launcher's reasoning settings map onto what the SDK accepts. The names in the UI
#: describe the trade the engineer is making; the SDK's do not.
REASONING_EFFORT = {"fast": "low", "balanced": "medium", "thorough": "high"}


def configured_reasoning_effort() -> str:
    return REASONING_EFFORT.get(launcher_config.load_config().preferences.reasoning, "low")

complete = _runtime.complete
prewarm = _runtime.prewarm
auth = _runtime.auth
begin_device_login = _runtime.begin_device_login
cancel_device_login = _runtime.cancel_device_login
login_finished = _runtime.login_finished
refresh = _runtime.refresh
shutdown = _runtime.shutdown
models = _runtime.models
