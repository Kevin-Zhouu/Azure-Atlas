"""Live Kusto execution.

Queries run here rather than in the webview for two reasons: the webview would need the cluster
to permit cross-origin requests, and an access token would have to be handed to page JavaScript.
In this process the token is acquired from the Azure CLI the engineer has already signed into, is
never sent to the frontend, and never leaves the process except as an ``Authorization`` header
addressed to a validated cluster.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from contextvars import ContextVar
from typing import Any

import httpx

from . import azure_auth, launcher_config
from .config import settings
from .models import (
    AuthStatus,
    Column,
    DatabaseSchema,
    QueryResult,
    SchemaColumn,
    TableSchema,
    Visualization,
)

#: Rows beyond this are dropped before reaching the UI; the table is a triage surface, not an export.
MAX_ROWS = 2_000
MAX_QUERY_CHARS = 100_000
REQUEST_TIMEOUT_SECONDS = 90.0
#: Kept deliberately narrow, and identical to the guard in ``src/providers/kusto.ts``.
ALLOWED_SUFFIXES = (".kusto.windows.net", ".kusto.azuresynapse.net")
_HOST_CHARACTERS = set("abcdefghijklmnopqrstuvwxyz0123456789-")


class KustoError(Exception):
    """A message written for the engineer reading it, not a stack trace."""


logger = logging.getLogger("atlas.kusto")


#: Both the client and the lock belong to the loop that created them. The service runs one loop
#: for its lifetime, but keying by loop keeps the module correct anywhere else it is used.
_per_loop: dict[asyncio.AbstractEventLoop, tuple[httpx.AsyncClient, asyncio.Lock]] = {}

#: Fetched schemas, keyed by cluster and database, with the time they were fetched.
_schema_cache: dict[tuple[str, str], tuple[float, DatabaseSchema]] = {}
_query_statistics: ContextVar[dict[str, str] | None] = ContextVar("query_statistics", default=None)


def read_statistics(tables: list[dict[str, Any]], statistics: dict[str, str]) -> None:
    for table in tables:
        columns = [column.get("ColumnName") for column in table.get("Columns") or []]
        for row in table.get("Rows") or []:
            record = dict(zip(columns, row))
            if record.get("EventTypeName") != "QueryResourceConsumption":
                continue
            raw = record.get("Payload")
            try:
                payload = json.loads(raw) if isinstance(raw, str) else raw
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            resource = payload.get("resource_usage") or {}
            cpu = resource.get("cpu") or {}
            memory = resource.get("memory") or {}
            dataset = payload.get("input_dataset_statistics") or {}
            extents = dataset.get("extents") or {}
            cache = ((resource.get("cache") or {}).get("shards") or {})
            values = {
                "cpuTime": cpu.get("total cpu") or cpu.get("total_cpu"),
                "peakMemory": memory.get("peak_per_node"),
                "dataScanned": dataset.get("scanned_bytes"),
                "extentsScanned": extents.get("scanned"),
                "cacheHit": cache.get("hot", {}).get("hitbytes") if isinstance(cache.get("hot"), dict) else None,
            }
            statistics.update({key: str(value) for key, value in values.items() if value is not None})


def _resources() -> tuple[httpx.AsyncClient, asyncio.Lock]:
    loop = asyncio.get_running_loop()
    existing = _per_loop.get(loop)
    if existing is not None and not existing[0].is_closed:
        return existing
    created = (
        httpx.AsyncClient(
            timeout=REQUEST_TIMEOUT_SECONDS,
            headers={
                "User-Agent": "AzureAtlas/0.1 (prototype)",
                # Without this the cluster reports semantic errors as plain text carrying only
                # "Request is invalid and cannot be executed". Asking for JSON returns the
                # SEM-coded explanation an engineer can actually act on.
                "Accept": "application/json",
            },
        ),
        asyncio.Lock(),
    )
    _per_loop[loop] = created
    return created


def http() -> httpx.AsyncClient:
    return _resources()[0]


async def shutdown() -> None:
    """Close every client this module opened. Safe to call more than once."""
    for client, _ in list(_per_loop.values()):
        if not client.is_closed:
            try:
                await client.aclose()
            except RuntimeError:
                # The owning loop has already gone; nothing is left to release.
                pass
    _per_loop.clear()


def normalise_cluster(raw: str) -> str:
    """Accept only an HTTPS origin on a known Kusto domain, and return it normalised.

    This repeats the frontend's validation on purpose. The frontend is where a mistake is most
    likely, and this is the process that holds the token.
    """
    trimmed = raw.strip().rstrip("/")
    if len(trimmed) <= len("https://") or not trimmed[: len("https://")].lower() == "https://":
        raise KustoError(
            "Use an HTTPS Kusto cluster URL, for example https://help.kusto.windows.net."
        )
    rest = trimmed[len("https://") :]
    if not rest or any(character in rest for character in "/@:?#"):
        raise KustoError("Enter the cluster origin only, without a path, port or credentials.")
    host = rest.lower()
    labels_valid = all(
        label and set(label) <= _HOST_CHARACTERS for label in host.split(".")
    )
    suffix_allowed = any(
        host.endswith(suffix) and len(host) > len(suffix) for suffix in ALLOWED_SUFFIXES
    )
    if not labels_valid or not suffix_allowed:
        raise KustoError(
            f'"{host}" is not an Azure Data Explorer cluster. '
            f"Expected a host ending in {' or '.join(ALLOWED_SUFFIXES)}."
        )
    return f"https://{host}"


def check_query(query: str) -> str:
    trimmed = query.strip()
    if not trimmed:
        raise KustoError("Enter a query to run.")
    if len(trimmed) > MAX_QUERY_CHARS:
        raise KustoError(f"Keep the query below {MAX_QUERY_CHARS} characters.")
    # Control commands can alter the cluster. Atlas only reads.
    if any(line.lstrip().startswith(".") for line in trimmed.splitlines()):
        raise KustoError("Management commands are disabled. Atlas runs read-only queries.")
    return trimmed


def run_az(args: list[str]) -> str:
    try:
        return azure_auth.run_az(args)
    except azure_auth.AzureAuthError as error:
        raise KustoError(str(error)) from error


async def access_token(cluster: str) -> str:
    """Return a cluster-scoped bearer token without exposing it outside the backend."""
    try:
        return await azure_auth.access_token(cluster)
    except azure_auth.AzureAuthError as error:
        raise KustoError(str(error)) from error


def primary_index(tables: list[dict[str, Any]]) -> int:
    """The v1 response ends with a table of contents naming the ordinal of the real result."""
    if len(tables) < 2:
        return 0
    toc = tables[-1]
    columns = [column.get("ColumnName") for column in toc.get("Columns") or []]
    if "Kind" not in columns or "Ordinal" not in columns:
        return 0
    kind_at, ordinal_at = columns.index("Kind"), columns.index("Ordinal")
    for row in toc.get("Rows") or []:
        if not isinstance(row, list) or len(row) <= max(kind_at, ordinal_at):
            continue
        if row[kind_at] != "QueryResult":
            continue
        ordinal = row[ordinal_at]
        try:
            # The ordinal arrives as a number on some clusters and a string on others.
            index = int(ordinal)
        except (TypeError, ValueError):
            continue
        if 0 <= index < len(tables):
            return index
    return 0


def _named_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, str) and item]
    if isinstance(value, str) and value:
        return [value]
    return []


def visualization_of(tables: list[dict[str, Any]]) -> Visualization | None:
    """Read the ``render`` directive out of the cluster's query-properties table.

    A v1 response carries an ``@ExtendedProperties`` table holding one JSON ``Value`` per
    property. The ``Visualization`` property is what ``| render`` produced. Clusters leave the
    axis fields null unless the query used ``with (...)``, so the client infers the rest.
    """
    for index, table in enumerate(tables):
        columns = [column.get("ColumnName") for column in table.get("Columns") or []]
        if columns != ["Value"]:
            continue
        # The last table is the table of contents, which also has a single column on some paths.
        if index == len(tables) - 1:
            continue
        for row in table.get("Rows") or []:
            if not isinstance(row, list) or not row:
                continue
            try:
                parsed = json.loads(row[0]) if isinstance(row[0], str) else row[0]
            except json.JSONDecodeError:
                continue
            if not isinstance(parsed, dict):
                continue
            kind = parsed.get("Visualization")
            if not isinstance(kind, str) or not kind:
                continue
            return Visualization(
                kind=kind,
                title=parsed.get("Title") if isinstance(parsed.get("Title"), str) else None,
                x_column=parsed.get("XColumn")
                if isinstance(parsed.get("XColumn"), str)
                else None,
                series=_named_list(parsed.get("Series")),
                y_columns=_named_list(parsed.get("YColumns")),
                x_title=parsed.get("XTitle") if isinstance(parsed.get("XTitle"), str) else None,
                y_title=parsed.get("YTitle") if isinstance(parsed.get("YTitle"), str) else None,
                accumulate=parsed.get("Accumulate") is True,
            )
    return None


def normalise_cell(cell: Any) -> Any:
    """``dynamic`` columns arrive as nested JSON; the table renders text, so flatten them."""
    if isinstance(cell, (list, dict)):
        return json.dumps(cell, separators=(",", ":"))
    return cell


def _truncate(text: str, limit: int) -> str:
    return text if len(text) <= limit else f"{text[:limit]}..."


def describe_failure(status: int, body: str) -> str:
    try:
        value = json.loads(body)
    except (json.JSONDecodeError, TypeError):
        value = None
    if isinstance(value, dict):
        error = value.get("error") or {}
        inner = error.get("innererror") or {} if isinstance(error, dict) else {}
        candidates = [
            inner.get("@message"),
            inner.get("message"),
            error.get("@message") if isinstance(error, dict) else None,
            error.get("message") if isinstance(error, dict) else None,
        ]
        message = next(
            (text for text in candidates if isinstance(text, str) and text.strip()), None
        )
        if message:
            code = error.get("code") if isinstance(error, dict) else None
            if isinstance(code, str) and code and not message.startswith(code):
                return f"{code}: {message}"
            return message
    if status in (401, 403):
        return (
            "The cluster rejected your credentials. Confirm you have access to this cluster "
            "and database, then run az login again."
        )
    if status == 404:
        return "The cluster or database was not found. Check the names and try again."
    if status == 429:
        return "The cluster is throttling requests. Wait a moment and run the query again."
    snippet = _plain_text_detail(body)
    if not snippet:
        return f"The cluster returned HTTP {status}."
    return f"The cluster returned HTTP {status}: {_truncate(snippet, 300)}"


def _plain_text_detail(body: str) -> str:
    """Strip the request-id trailer clusters append to plain-text errors.

    A body such as ``General_BadRequest: ... \\nError details:\\nClientRequestId='...'`` carries
    one useful sentence followed by correlation identifiers that mean nothing in the UI.
    """
    text = (body or "").strip()
    head = text.split("\nError details:", 1)[0].strip()
    return head or text


async def execute(
    cluster: str, database: str, csl: str, endpoint: str
) -> tuple[list[Column], list[list[Any]], Visualization | None]:
    """Post to one of the cluster's REST endpoints and return the primary table."""
    token = await access_token(cluster)
    statistics = _query_statistics.get()
    row_limit = launcher_config.load_config().preferences.rowLimit
    body = {
        "db": database,
        "csl": csl,
        "properties": {
            "Options": {
                "servertimeout": "00:01:00",
                "request_readonly": True,
                "truncationmaxrecords": row_limit,
            }
        },
    }
    headers = {"Authorization": f"Bearer {token}"}
    if statistics is not None:
        headers["x-ms-client-request-id"] = statistics["clientRequestId"]
    try:
        response = await http().post(
            f"{cluster}{endpoint}", json=body, headers=headers
        )
    except httpx.TimeoutException as error:
        raise KustoError(
            "The query timed out. Narrow the time range or add a limit, then run it again."
        ) from error
    except httpx.HTTPError as error:
        raise KustoError(f"The cluster could not be reached: {error}") from error

    if response.status_code >= 400:
        raise KustoError(describe_failure(response.status_code, response.text))
    try:
        payload = response.json()
        tables = payload["Tables"]
    except (ValueError, KeyError, TypeError) as error:
        raise KustoError("The cluster response could not be parsed.") from error
    if not isinstance(tables, list) or not tables:
        raise KustoError("The cluster returned no result table.")
    if statistics is not None:
        read_statistics(tables, statistics)

    table = tables[primary_index(tables)]
    columns = [
        Column(
            name=column.get("ColumnName") or "Column",
            type=column.get("ColumnType") or column.get("DataType") or "string",
        )
        for column in table.get("Columns") or []
    ]
    rows = [
        [normalise_cell(cell) for cell in row]
        for row in table.get("Rows") or []
        if isinstance(row, list)
    ]
    return columns, rows, visualization_of(tables)


async def auth_status() -> AuthStatus:
    return await azure_auth.auth_status()


async def run_query(cluster: str, database: str, query: str) -> QueryResult:
    cluster = normalise_cluster(cluster)
    database = database.strip()
    if not database:
        raise KustoError("Choose a database.")
    query = check_query(query)

    started = time.monotonic()
    statistics = {"clientRequestId": f"AzureAtlas.Query;{uuid.uuid4()}"}
    context = _query_statistics.set(statistics)
    try:
        columns, rows, visualization = await execute(cluster, database, query, "/v1/rest/query")
    finally:
        _query_statistics.reset(context)
    duration_ms = int((time.monotonic() - started) * 1000)
    total_rows = len(rows)
    row_limit = launcher_config.load_config().preferences.rowLimit
    return QueryResult(
        columns=columns,
        rows=rows[:row_limit],
        duration_ms=duration_ms,
        source="Live",
        truncated=total_rows > row_limit,
        total_rows=total_rows,
        visualization=visualization,
        statistics=statistics,
    )


async def list_databases(cluster: str) -> list[str]:
    """List a cluster's databases so the runner can offer them instead of asking the engineer
    to remember exact names."""
    cluster = normalise_cluster(cluster)
    # `.show databases` is cluster-scoped, and NetDefaultDB exists on every cluster. Atlas issues
    # this itself, so it legitimately bypasses the guard that blocks user-authored commands.
    columns, rows, _ = await execute(
        cluster,
        "NetDefaultDB",
        ".show databases | project DatabaseName | sort by DatabaseName asc",
        "/v1/rest/mgmt",
    )
    names = [column.name for column in columns]
    name_at = names.index("DatabaseName") if "DatabaseName" in names else 0
    seen: list[str] = []
    for row in rows:
        if len(row) <= name_at:
            continue
        value = row[name_at]
        if isinstance(value, str) and value and value not in seen:
            seen.append(value)
    return seen


async def database_schema(cluster: str, database: str) -> DatabaseSchema:
    """Return the selected database's tables and columns, from cache when it is fresh.

    Generation needs the schema on every request, and the cluster takes roughly half a second
    to hand it over even when warm. Caching it moves that cost out of the engineer's wait.
    """
    cluster = normalise_cluster(cluster)
    database = database.strip()
    if not database:
        raise KustoError("Choose a database.")

    key = (cluster, database)
    cached = _schema_cache.get(key)
    if cached is not None and (time.monotonic() - cached[0]) < settings.schema_ttl:
        return cached[1]

    schema = await _fetch_database_schema(cluster, database)
    _schema_cache[key] = (time.monotonic(), schema)
    return schema


async def prewarm_schema(cluster: str, database: str) -> None:
    """Fetch a schema in the background so the next generation does not wait for it."""
    try:
        await database_schema(cluster, database)
    except Exception:  # noqa: BLE001 - prewarming must never fail the caller
        logger.debug("Prewarming the schema for %s/%s failed", cluster, database, exc_info=True)


async def _fetch_database_schema(cluster: str, database: str) -> DatabaseSchema:
    """Ask the cluster for the schema, bypassing the cache."""
    _, rows, _ = await execute(
        cluster, database, ".show database schema as json", "/v1/rest/mgmt"
    )
    raw = next((cell for row in rows for cell in row if isinstance(cell, str)), None)
    if raw is None:
        raise KustoError("The cluster returned no database schema.")
    try:
        payload = json.loads(raw)
        databases = payload.get("Databases") or payload.get("databases") or {}
        selected = databases.get(database) or next(iter(databases.values()))
        table_map = selected.get("Tables") or selected.get("tables") or {}
    except (json.JSONDecodeError, AttributeError, StopIteration) as error:
        raise KustoError("The database schema response could not be parsed.") from error

    tables = []
    for name, table in sorted(table_map.items()):
        raw_columns = table.get("OrderedColumns") or table.get("orderedColumns") or []
        columns = [
            SchemaColumn(
                name=str(column.get("Name") or column.get("name") or "Column"),
                type=str(column.get("CslType") or column.get("Type") or column.get("type") or "string"),
            )
            for column in raw_columns
            if isinstance(column, dict)
        ]
        tables.append(TableSchema(name=name, columns=columns))
    return DatabaseSchema(cluster=cluster, database=database, tables=tables)
