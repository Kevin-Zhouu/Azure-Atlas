"""Browser device flows. Only codes and identity metadata cross the local API."""
from __future__ import annotations

import asyncio
import base64
import json
import time

import httpx

from . import credentials

AZURE_CLIENT = "04b07795-8ddb-461a-bbee-02f9e1bf7b46"
GITHUB_CLIENT = "Iv1.b507a08c87ecfe98"
AZURE_AUTHORITY = "https://login.microsoftonline.com/organizations/oauth2/v2.0"
ADO_RESOURCE = "499b84ac-1321-427f-aa17-267ca6975798"
_tasks: dict[str, asyncio.Task] = {}
_errors: dict[str, str] = {}


class AccountError(RuntimeError):
    pass


async def _post(url: str, data: dict) -> dict:
    try:
        async with httpx.AsyncClient(timeout=30, follow_redirects=False) as client:
            response = await client.post(url, data=data, headers={"Accept": "application/json"})
            body = response.json()
            if not isinstance(body, dict):
                raise ValueError()
            if response.is_error and not body.get("error"):
                raise AccountError(f"Sign-in service returned HTTP {response.status_code}.")
            return body
    except (httpx.HTTPError, ValueError) as error:
        raise AccountError("The sign-in service could not be reached or returned an invalid response.") from error


async def begin(provider: str) -> dict[str, str]:
    credentials._api()  # Fail before starting a flow if no secure store exists.
    await cancel(provider)
    _errors.pop(provider, None)
    azure = provider == "azure"
    response = await _post(
        f"{AZURE_AUTHORITY}/devicecode" if azure else "https://github.com/login/device/code",
        {"client_id": AZURE_CLIENT, "scope": f"{ADO_RESOURCE}/.default offline_access openid profile"}
        if azure else {"client_id": GITHUB_CLIENT, "scope": "read:user repo"},
    )
    if not all(response.get(key) for key in ("device_code", "user_code", "verification_uri")):
        raise AccountError(str(response.get("error_description") or "Device sign-in could not be started."))
    _tasks[provider] = asyncio.create_task(_poll(provider, response))
    return {"verificationUri": response["verification_uri"], "userCode": response["user_code"]}


async def _poll(provider: str, flow: dict) -> None:
    azure = provider == "azure"
    interval = max(5, int(flow.get("interval", 5)))
    deadline = time.monotonic() + int(flow.get("expires_in", 900))
    try:
        while time.monotonic() < deadline:
            await asyncio.sleep(interval)
            response = await _post(
                f"{AZURE_AUTHORITY}/token" if azure else "https://github.com/login/oauth/access_token",
                {"client_id": AZURE_CLIENT if azure else GITHUB_CLIENT, "device_code": flow["device_code"],
                 "grant_type": "urn:ietf:params:oauth:grant-type:device_code"},
            )
            if response.get("error") in ("authorization_pending", "slow_down"):
                if response["error"] == "slow_down":
                    interval += 5
                continue
            if response.get("error"):
                raise AccountError(str(response.get("error_description") or response["error"]))
            if azure:
                if not response.get("refresh_token"):
                    raise AccountError("Azure did not return a refresh token. Sign in again.")
                account, tenant = "Azure account", ""
                if response.get("id_token"):
                    # Only a display label; authorization always uses the service-issued access token.
                    segment = response["id_token"].split(".")[1]
                    claims = json.loads(base64.urlsafe_b64decode(segment + "=" * (-len(segment) % 4)))
                    account, tenant = claims.get("preferred_username", account), claims.get("tid", "")
                credentials.write("azure", {"refresh_token": response["refresh_token"], "account": account, "tenant": tenant})
                from . import azure_auth
                azure_auth._tokens.clear()
            else:
                token = response.get("access_token")
                if not token:
                    raise AccountError("GitHub did not return a token.")
                async with httpx.AsyncClient(timeout=30) as client:
                    identity = await client.get("https://api.github.com/user", headers={"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"})
                    identity.raise_for_status()
                    account = identity.json()["login"]
                credentials.write("copilot", {"token": token, "account": account})
                from . import copilot_llm
                await copilot_llm.refresh()
            return
        raise AccountError("The device code expired. Start sign-in again.")
    except (AccountError, credentials.CredentialError, httpx.HTTPError, ValueError, KeyError, IndexError) as error:
        _errors[provider] = str(error)


def status_error(provider: str) -> str:
    return _errors.get(provider, "")


async def cancel(provider: str) -> None:
    task = _tasks.pop(provider, None)
    if task and not task.done():
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


async def logout(provider: str) -> None:
    await cancel(provider)
    credentials.write(provider, {"disabled": True})
    _errors.pop(provider, None)


async def azure_token(resource: str) -> str | None:
    saved = credentials.read("azure")
    if saved is None:
        return None
    if saved.get("disabled"):
        raise AccountError("Signed out of Azure Atlas. Sign in under Preferences → General.")
    response = await _post(f"{AZURE_AUTHORITY}/token", {
        "client_id": AZURE_CLIENT, "grant_type": "refresh_token", "refresh_token": saved["refresh_token"],
        "scope": f"{resource.rstrip('/')}/.default",
    })
    if not response.get("access_token"):
        raise AccountError("Azure could not authorize this resource. Sign in again or check your permissions.")
    if response.get("refresh_token"):
        credentials.write("azure", {**saved, "refresh_token": response["refresh_token"]})
    return response["access_token"]
